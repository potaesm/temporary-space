function NewJoinerJourney(newJoinerJourneyId = null, newJoinerId = null, journeyId = null) {
	this.newJoinerJourneyId = newJoinerJourneyId;
	this.newJoinerId = newJoinerId;
	this.journeyId = journeyId;
}
NewJoinerJourney.prototype.map = function (object) {
	if (!object) return;
	object.newJoinerJourneyId !== undefined ? this.newJoinerJourneyId = object.newJoinerJourneyId : void (0);
	object.newJoinerId !== undefined ? this.newJoinerId = object.newJoinerId : void (0);
	object.journeyId !== undefined ? this.journeyId = object.journeyId : void (0);
}
NewJoinerJourney.prototype.get = function (options = { mandatory: false, optional: false, present: false, compact: false }) {
	let o = {
		_newJoinerJourneyId: this.newJoinerJourneyId,
		newJoinerId: this.newJoinerId,
		journeyId: this.journeyId
	};
	if (options.mandatory && !options.optional) o = Object.fromEntries(Object.entries(o).filter(_ => !_[0].startsWith('_')));
	if (options.optional && !options.mandatory) o = Object.fromEntries(Object.entries(o).filter(_ => _[0].startsWith('_')));
	if (options.present) o = Object.fromEntries(Object.entries(o).filter(_ => _[1] !== null));
	if (options.compact) o = Object.fromEntries(Object.entries(o).filter(_ => !!_[1]));
	return Object.fromEntries(Object.entries(o).map(_ => { _[0] = _[0].replace('_', ''); return _; }));
}
NewJoinerJourney.prototype.getNewJoinerJourneyId = function () { return this.newJoinerJourneyId }
NewJoinerJourney.prototype.getNewJoinerId = function () { return this.newJoinerId }
NewJoinerJourney.prototype.getJourneyId = function () { return this.journeyId }
NewJoinerJourney.prototype.setNewJoinerJourneyId = function (newJoinerJourneyId) { newJoinerJourneyId !== undefined ? this.newJoinerJourneyId = newJoinerJourneyId : void (0) }
NewJoinerJourney.prototype.setNewJoinerId = function (newJoinerId) { newJoinerId !== undefined ? this.newJoinerId = newJoinerId : void (0) }
NewJoinerJourney.prototype.setJourneyId = function (journeyId) { journeyId !== undefined ? this.journeyId = journeyId : void (0) }
NewJoinerJourney.prototype.isEmpty = function () { return !Object.values(this).filter(_ => _ !== null).length }
NewJoinerJourney.prototype.isFull = function () { return !Object.values(this).includes(null) }
NewJoinerJourney.prototype.isValid = function (options = { mandatory: false, optional: false }) {
	const o = {
		_newJoinerJourneyId: this.newJoinerJourneyId,
		newJoinerId: this.newJoinerId,
		journeyId: this.journeyId
	};
	let entries = Object.entries(o);
	if (options.mandatory && !options.optional) entries = entries.filter(_ => !_[0].startsWith('_'));
	if (options.optional && !options.mandatory) entries = entries.filter(_ => _[0].startsWith('_'));
	return !Object.values(Object.fromEntries(entries)).includes(null);
}
NewJoinerJourney.prototype.listMissingFields = function (options = { mandatory: false, optional: false }) {
	const o = {
		_newJoinerJourneyId: this.newJoinerJourneyId,
		newJoinerId: this.newJoinerId,
		journeyId: this.journeyId
	};
	let entries = Object.entries(o);
	if (options.mandatory && !options.optional) entries = entries.filter(_ => !_[0].startsWith('_'));
	if (options.optional && !options.mandatory) entries = entries.filter(_ => _[0].startsWith('_'));
	return entries.filter(_ => _[1] === null).map(_ => _[0].replace('_', ''));
}
module.exports = NewJoinerJourney;
