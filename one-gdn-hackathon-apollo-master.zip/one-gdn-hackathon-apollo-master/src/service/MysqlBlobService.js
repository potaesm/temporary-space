const fs = require('fs-extra');

function getBlob(path = '') {
    return new Promise(async (resolve, reject) => {
        try {
            const blob = await fs.readFile(path);
            return resolve(Uint8Array.from(Buffer.from(blob)));
        } catch (error) {
            return reject(error);
        }
    });
};

function getMimeType(fileName = '') {
    const imageTypeList = ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'heic'];
    const applicationTypeList = ['efi', 'json', 'pdf', 'zip'];
    const audioTypeList = ['3gpp', 'aac', 'mp4', 'mpeg', 'ogg',];
    const textTypeList = ['csv', 'html'];
    const fileExtension = `${fileName.split('.').pop()}`.toLowerCase();
    let mimeType = 'application/octet-stream';
    if (imageTypeList.includes(fileExtension)) {
        mimeType = `image/${fileExtension}`;
    }
    if (applicationTypeList.includes(fileExtension)) {
        mimeType = `application/${fileExtension}`;
    }
    if (audioTypeList.includes(fileExtension)) {
        mimeType = `audio/${fileExtension}`;
    }
    if (textTypeList.includes(fileExtension)) {
        mimeType = `text/${fileExtension}`;
    }
    if (fileExtension === 'mp3') {
        mimeType = 'audio/mpeg'
    }
    if (fileExtension === 'txt') {
        mimeType = 'text/plain'
    }
    return mimeType;
}

module.exports = {
    getBlob,
    getMimeType
};
