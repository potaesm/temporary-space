const cookieConfig = require('../config/cookieConfig.json');
const { UserService } = require('../service');
const { MysqlService } = require('../service');
const { validateUserPassword, validateRequiredPermission, validateJwtInCookies } = require('../middleware/Auth');
const { table } = require('../config/dbConfig.json');

module.exports = (router = require('express').Router()) => {
    router.post('/create', async (request, response) => {
        try {
            const result = await UserService.createUser(request.body);
            return response.send(result);
        } catch (error) {
            return response.status(500).send(error);
        }
    });

    router.get('/list/:username?', async (request, response) => {
        try {
            const results = await UserService.getUser(request.params.username);
            return response.send(results);
        } catch (error) {
            return response.status(500).send(error);
        }
    });

    router.post('/login', validateUserPassword, async (request, response) => {
        try {
            const result = await UserService.login(request.body);
            // response.cookie('jwt', accessToken, cookieConfig.cookieOptions);
            return response.send(result);
        } catch (error) {
            return response.status(500).send(error);
        }
    });

    router.patch('/update/:userId', async (request, response) => {
        try {
            const result = await UserService.updateUser(request.params.userId, request.body);
            return response.send(result);
        } catch (error) {
            return response.status(500).send(error);
        }
    });

    router.delete('/delete/:userId?', async (request, response) => {
        try {
            const result = await UserService.deleteUser(request.params.userId);
            return response.send(result);
        } catch (error) {
            return response.status(500).send(error);
        }
    });

    return router;
};
