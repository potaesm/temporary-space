const { Task } = require('../model');
const { TaskService } = require('../service');

module.exports = (router = require('express').Router()) => {
    router.get('/list/:taskId?', async (request, response) => {
        try {
            const taskId = request.params.taskId;
            const results = await TaskService.getTask(taskId);
            return response.send(results);
        } catch (error) {
            return response.status(500).send(error);
        }
    });

    router.post('/create/:journeyId/:fileId', async (request, response) => {
        try {
            const fileId = request.params.fileId;
            const journeyId = request.params.journeyId;
            const newTask = new Task();
            newTask.map({ ...request.body, fileId, journeyId });
            if (newTask.isValid({ mandatory: true })) {
                const result = await TaskService.createTask(journeyId, fileId, request.body);
                return response.send(result);
            }
            throw { message: `missing ${newTask.listMissingFields({ mandatory: true })}` };
        } catch (error) {
            return response.status(500).send(error);
        }
    });

    router.patch('/update/:taskId', async (request, response) => {
        try {
            const taskId = request.params.taskId;
            const newTask = new Task();
            newTask.map(request.body);
            if (!!newTask.isValid({ mandatory: true })) {
                const result = await TaskService.updateTask(taskId, request.body);
                return response.send(result);
            }
            throw { message: `missing ${newTask.listMissingFields({ mandatory: true })}` };
        } catch (error) {
            return response.status(500).send(error);
        }
    });

    router.delete('/delete/:taskId?', async (request, response) => {
        try {
            const taskId = request.params.taskId;
            const result = await TaskService.deleteTask(taskId);
            return response.send(result);
        } catch (error) {
            return response.status(500).send(error);
        }
    });

    return router;
};
