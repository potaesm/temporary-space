const { QUERY, FIND, INSERT, UPDATE, DELETE } = require('../repository/MysqlRepository');

async function findPage(table, indexName, sortObject, pageSize, pageNumber) {
	const results = await FIND({ table, indexName, sortObject, pageSize, pageNumber });
	return results;
}

async function findWhere(table, indexName, findObject) {
	const results = await FIND({ table, indexName, findObject });
	return results;
}

async function findById(table, id) {
	const results = await FIND({ table, indexName: 'id', findObject: { id } });
	return results;
}

async function insert(table, indexName, docs) {
	const results = await INSERT({ table, indexName, doc: docs });
	return results;
}

async function updateById(table, id, doc) {
	const results = await UPDATE({ table, indexName: 'id', findObject: { id }, doc });
	return results;
}

async function updateWhere(table, findObject, doc) {
	const results = await UPDATE({ table, findObject, doc });
	return results;
}

async function deleteById(table, id) {
	const results = await DELETE({ table, findObject: { id } });
	return results;
}

async function deleteWhere(table, findObject) {
	const results = await DELETE({ table, findObject });
	return results;
}

module.exports = {
	findPage,
	findWhere,
	findById,
	insert,
	updateById,
	updateWhere,
	deleteById,
	deleteWhere,
	QUERY,
};
