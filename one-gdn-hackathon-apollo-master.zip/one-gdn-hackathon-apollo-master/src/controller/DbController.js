const { mysqlConfig, table } = require('../config/dbConfig.json');
const { MysqlService } = require('../service');

module.exports = (router = require('express').Router()) => {
    router.get('/user', async (request, response) => {
        try {
            const results = await MysqlService.QUERY(
                'CREATE TABLE `' +
                mysqlConfig.database +
                '`.`user` ( `userId` INT NOT NULL AUTO_INCREMENT, `employeeId` VARCHAR(45) NULL, `name` VARCHAR(45) NULL, `username` VARCHAR(45) NOT NULL, `password` VARCHAR(200) NOT NULL, `userType` INT NULL, PRIMARY KEY (`userId`));'
            );
            return response.send(results);
        } catch (error) {
            return response.status(500).send(error);
        }
    });

    router.get('/hr', async (request, response) => {
        try {
            const results = await MysqlService.QUERY(
                'CREATE TABLE `' +
                mysqlConfig.database +
                '`.`hr` ( `hrId` INT NOT NULL AUTO_INCREMENT, `userId` INT NULL, PRIMARY KEY (`hrId`), INDEX `userId_idx` (`userId` ASC) VISIBLE, CONSTRAINT `hrUserId` FOREIGN KEY (`userId`) REFERENCES `' + mysqlConfig.database + '`.`user` (`userId`) ON DELETE CASCADE ON UPDATE NO ACTION);'
            );
            return response.send(results);
        } catch (error) {
            return response.status(500).send(error);
        }
    });

    router.get('/new-joiner', async (request, response) => {
        try {
            const results = await MysqlService.QUERY(
                'CREATE TABLE `' +
                mysqlConfig.database +
                '`.`new_joiner` ( `newJoinerId` INT NOT NULL AUTO_INCREMENT, `userId` INT NULL, `manager` VARCHAR(45) NULL, `team` VARCHAR(45) NULL, `startDate` DATETIME NULL, `probationEndDate` DATETIME NULL, PRIMARY KEY (`newJoinerId`), INDEX `newJoinerUserId_idx` (`userId` ASC) VISIBLE, CONSTRAINT `newJoinerUserId` FOREIGN KEY (`userId`) REFERENCES `' + mysqlConfig.database + '`.`user` (`userId`) ON DELETE CASCADE ON UPDATE NO ACTION);'
            );
            return response.send(results);
        } catch (error) {
            return response.status(500).send(error);
        }
    });

    router.get('/journey', async (request, response) => {
        try {
            const results = await MysqlService.QUERY(
                'CREATE TABLE `' +
                mysqlConfig.database +
                '`.`journey` ( `journeyId` INT NOT NULL AUTO_INCREMENT, `journeyName` VARCHAR(45) NULL, PRIMARY KEY (`journeyId`));'
            );
            return response.send(results);
        } catch (error) {
            return response.status(500).send(error);
        }
    });

    router.get('/task', async (request, response) => {
        try {
            const results = await MysqlService.QUERY(
                'CREATE TABLE `' +
                mysqlConfig.database +
                '`.`task` ( `taskId` INT NOT NULL AUTO_INCREMENT, `journeyId` INT NULL, `fileId` INT NULL, `taskType` INT NULL, `taskName` VARCHAR(100) NULL, `taskContent` VARCHAR(45) NULL, `response` VARCHAR(45) NULL, PRIMARY KEY (`taskId`), INDEX `taskJourneyId_idx` (`journeyId` ASC) VISIBLE, INDEX `taskFileId_idx` (`fileId` ASC) VISIBLE, CONSTRAINT `taskJourneyId` FOREIGN KEY (`journeyId`) REFERENCES `' + mysqlConfig.database + '`.`journey` (`journeyId`) ON DELETE CASCADE ON UPDATE NO ACTION, CONSTRAINT `taskFileId` FOREIGN KEY (`fileId`) REFERENCES `' + mysqlConfig.database + '`.`file` (`fileId`) ON DELETE CASCADE ON UPDATE NO ACTION);'
            );
            return response.send(results);
        } catch (error) {
            return response.status(500).send(error);
        }
    });

    router.get('/new-joiner-journey', async (request, response) => {
        try {
            const results = await MysqlService.QUERY(
                'CREATE TABLE `' +
                mysqlConfig.database +
                '`.`new_joiner_journey` ( `newJoinerJourneyId` INT NOT NULL AUTO_INCREMENT, `newJoinerId` INT NULL, `journeyId` INT NULL, PRIMARY KEY (`newJoinerJourneyId`), INDEX `newJoinerJourneyNewJoinerId_idx` (`newJoinerId` ASC) VISIBLE, INDEX `newJoinerJourneyJourneyId_idx` (`journeyId` ASC) VISIBLE, CONSTRAINT `newJoinerJourneyNewJoinerId` FOREIGN KEY (`newJoinerId`) REFERENCES `' + mysqlConfig.database + '`.`new_joiner` (`newJoinerId`) ON DELETE CASCADE ON UPDATE NO ACTION, CONSTRAINT `newJoinerJourneyJourneyId` FOREIGN KEY (`journeyId`) REFERENCES `' + mysqlConfig.database + '`.`journey` (`journeyId`) ON DELETE CASCADE ON UPDATE NO ACTION);'
            );
            return response.send(results);
        } catch (error) {
            return response.status(500).send(error);
        }
    });

    router.get('/file', async (request, response) => {
        try {
            const results = await MysqlService.QUERY(
                'CREATE TABLE `' +
                mysqlConfig.database +
                '`.`file` ( `fileId` INT NOT NULL AUTO_INCREMENT, `fileName` VARCHAR(45) NULL, `mimetype` VARCHAR(45) NULL, `data` LONGBLOB NULL, PRIMARY KEY (`fileId`));'
            );
            return response.send(results);
        } catch (error) {
            return response.status(500).send(error);
        }
    });

    router.get('/all', async (request, response) => {
        try {
            await MysqlService.QUERY(
                'CREATE TABLE `' +
                mysqlConfig.database +
                '`.`user` ( `userId` INT NOT NULL AUTO_INCREMENT, `employeeId` VARCHAR(45) NULL, `name` VARCHAR(45) NULL, `username` VARCHAR(45) NOT NULL, `password` VARCHAR(200) NOT NULL, `userType` INT NULL, PRIMARY KEY (`userId`));'
            );
            await MysqlService.QUERY(
                'CREATE TABLE `' +
                mysqlConfig.database +
                '`.`hr` ( `hrId` INT NOT NULL AUTO_INCREMENT, `userId` INT NULL, PRIMARY KEY (`hrId`), INDEX `userId_idx` (`userId` ASC) VISIBLE, CONSTRAINT `hrUserId` FOREIGN KEY (`userId`) REFERENCES `' + mysqlConfig.database + '`.`user` (`userId`) ON DELETE CASCADE ON UPDATE NO ACTION);'
            );
            await MysqlService.QUERY(
                'CREATE TABLE `' +
                mysqlConfig.database +
                '`.`new_joiner` ( `newJoinerId` INT NOT NULL AUTO_INCREMENT, `userId` INT NULL, `manager` VARCHAR(45) NULL, `team` VARCHAR(45) NULL, `startDate` DATETIME NULL, `probationEndDate` DATETIME NULL, PRIMARY KEY (`newJoinerId`), INDEX `newJoinerUserId_idx` (`userId` ASC) VISIBLE, CONSTRAINT `newJoinerUserId` FOREIGN KEY (`userId`) REFERENCES `' + mysqlConfig.database + '`.`user` (`userId`) ON DELETE CASCADE ON UPDATE NO ACTION);'
            );
            await MysqlService.QUERY(
                'CREATE TABLE `' +
                mysqlConfig.database +
                '`.`journey` ( `journeyId` INT NOT NULL AUTO_INCREMENT, `journeyName` VARCHAR(45) NULL, PRIMARY KEY (`journeyId`));'
            );
            await MysqlService.QUERY(
                'CREATE TABLE `' +
                mysqlConfig.database +
                '`.`file` ( `fileId` INT NOT NULL AUTO_INCREMENT, `fileName` VARCHAR(45) NULL, `mimetype` VARCHAR(45) NULL, `data` LONGBLOB NULL, PRIMARY KEY (`fileId`));'
            );
            await MysqlService.QUERY(
                'CREATE TABLE `' +
                mysqlConfig.database +
                '`.`new_joiner_journey` ( `newJoinerJourneyId` INT NOT NULL AUTO_INCREMENT, `newJoinerId` INT NULL, `journeyId` INT NULL, PRIMARY KEY (`newJoinerJourneyId`), INDEX `newJoinerJourneyNewJoinerId_idx` (`newJoinerId` ASC) VISIBLE, INDEX `newJoinerJourneyJourneyId_idx` (`journeyId` ASC) VISIBLE, CONSTRAINT `newJoinerJourneyNewJoinerId` FOREIGN KEY (`newJoinerId`) REFERENCES `' + mysqlConfig.database + '`.`new_joiner` (`newJoinerId`) ON DELETE CASCADE ON UPDATE NO ACTION, CONSTRAINT `newJoinerJourneyJourneyId` FOREIGN KEY (`journeyId`) REFERENCES `' + mysqlConfig.database + '`.`journey` (`journeyId`) ON DELETE CASCADE ON UPDATE NO ACTION);'
            );
            await MysqlService.QUERY(
                'CREATE TABLE `' +
                mysqlConfig.database +
                '`.`task` ( `taskId` INT NOT NULL AUTO_INCREMENT, `journeyId` INT NULL, `fileId` INT NULL, `taskType` INT NULL, `taskName` VARCHAR(100) NULL, `taskContent` INT NULL, `response` VARCHAR(45) NULL, PRIMARY KEY (`taskId`), INDEX `taskJourneyId_idx` (`journeyId` ASC) VISIBLE, INDEX `taskFileId_idx` (`fileId` ASC) VISIBLE, CONSTRAINT `taskJourneyId` FOREIGN KEY (`journeyId`) REFERENCES `' + mysqlConfig.database + '`.`journey` (`journeyId`) ON DELETE CASCADE ON UPDATE NO ACTION, CONSTRAINT `taskFileId` FOREIGN KEY (`fileId`) REFERENCES `' + mysqlConfig.database + '`.`file` (`fileId`) ON DELETE CASCADE ON UPDATE NO ACTION);'
            );
            return response.send({ message: 'done' });
        } catch (error) {
            return response.status(500).send(error);
        }
    });

    return router;
};
