const { Journey } = require('../model');
const { JourneyService } = require('../service');

module.exports = (router = require('express').Router()) => {
    router.get('/list/:journeyId?', async (request, response) => {
        try {
            const journeyId = request.params.journeyId;
            const results = await JourneyService.getJourney(journeyId);
            return response.send(results);
        } catch (error) {
            return response.status(500).send(error);
        }
    });

    router.post('/create', async (request, response) => {
        try {
            const result = await JourneyService.createJourney(request.body);
            return response.send(result);
        } catch (error) {
            return response.status(500).send(error);
        }
    });

    router.patch('/update/:journeyId', async (request, response) => {
        try {
            const journeyId = request.params.journeyId;
            const newJourney = new Journey();
            newJourney.map(request.body);
            if (!!newJourney.getJourneyName()) {
                const result = await JourneyService.updateJourney(journeyId, newJourney.get({ present: true }));
                return response.send(result);
            }
            throw { message: `journeyName is mandatory` };
        } catch (error) {
            return response.status(500).send(error);
        }
    });

    router.delete('/delete/:journeyId?', async (request, response) => {
        try {
            const journeyId = request.params.journeyId;
            const result = await JourneyService.deleteJourney(journeyId);
            return response.send(result);
        } catch (error) {
            return response.status(500).send(error);
        }
    });

    return router;
};
