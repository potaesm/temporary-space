const crypto = require('crypto');
const MysqlService = require('./MysqlService');
const HrService = require('./HrService');
const NewJoinerService = require('./NewJoinerService');

const { table, userType } = require('../config/dbConfig.json');
const { User } = require('../model');

function createUser(body = {}) {
    return new Promise(async (resolve, reject) => {
        try {
            const newUser = new User();
            newUser.map(body);
            if (newUser.isValid({ mandatory: true })) {
                /** Check if username existed */
                const existUserResults = await MysqlService.findWhere(table.user.name, table.user.indexName, { username: newUser.getUsername() });
                if (!!existUserResults && !!existUserResults.length) {
                    throw { message: 'duplicate username' };
                }
                /** Hash password */
                const salt = crypto.randomBytes(16).toString('base64');
                const hash = crypto.createHmac('sha512', salt).update(newUser.getPassword()).digest('base64');
                newUser.setPassword(salt + '$' + hash);
                /** Insert to DB */
                const result = await MysqlService.insert(table.user.name, table.user.indexName, newUser.get({ present: true }));
                /** Update dependent table */
                switch (newUser.getUserType()) {
                    case userType.hr: {
                        await HrService.createHr(result.insertId);
                        break;
                    }
                    case userType.newJoiner: {
                        await NewJoinerService.createNewJoiner(result.insertId);
                        break;
                    }
                    default:
                        break;
                }
                return resolve(result);
            }
            throw { message: `missing ${newUser.listMissingFields({ mandatory: true }).join(', ')}` };
        } catch (error) {
            return reject(error);
        }
    });
};

function getUser(username = '') {
    return new Promise(async (resolve, reject) => {
        try {
            const findObject = !!username ? { username } : {};
            let users = await MysqlService.findWhere(table.user.name, table.user.indexName, findObject);
            users = users.map(item => {
                const user = new User();
                user.map(item);
                user.setPassword(null);
                return user.get({ present: true });
            });
            return resolve(users);
        } catch (error) {
            return reject(error);
        }
    });
}

function updateUser(userId, body) {
    return new Promise(async (resolve, reject) => {
        try {
            const newUser = new User();
            newUser.map(body);
            if (!newUser.isEmpty()) {
                /** Check if userId not existed */
                const existUserResults = await MysqlService.findWhere(table.user.name, table.user.indexName, { userId });
                const existUser = new User();
                existUser.map(existUserResults[0]);
                if (!!existUserResults && !existUserResults.length) {
                    throw { message: 'no user found' };
                }
                /** If try to change username, check duplication */
                if (!!newUser.getUsername()) {
                    const sameUsernameUserResults = await MysqlService.findWhere(table.user.name, table.user.indexName, { username: newUser.getUsername() });
                    if (!!sameUsernameUserResults && !!sameUsernameUserResults.length) {
                        const sameUsernameUser = new User();
                        sameUsernameUser.map(sameUsernameUserResults[0]);
                        if (existUser.getUserId() !== sameUsernameUser.getUserId()) {
                            throw { message: 'duplicate username' };
                        }
                    }
                }
                /** If try to change password, hash new password */
                if (!!newUser.getPassword()) {
                    const salt = crypto.randomBytes(16).toString('base64');
                    const hash = crypto.createHmac('sha512', salt).update(newUser.getPassword()).digest('base64');
                    newUser.setPassword(salt + '$' + hash);
                }
                /** Update to DB */
                await MysqlService.updateWhere(table.user.name, { userId }, newUser.get({ present: true }));
                return resolve({ message: 'updated' });
            } else {
                throw { message: 'empty body' };
            }
        } catch (error) {
            return reject(error);
        }
    });
}

function deleteUser(userId) {
    return new Promise(async (resolve, reject) => {
        try {
            const findObject = {};
            if (userId !== undefined && userId !== null) {
                findObject[`${table.user.indexName}`] = userId;
            }
            const result = await MysqlService.deleteWhere(table.user.name, findObject);
            return resolve(result);
        } catch (error) {
            return reject(error);
        }
    });
}

function login(body = {}) {
    return new Promise(async (resolve, reject) => {
        try {
            const user = new User();
            user.map(body);
            if (!user.getUserId()) {
                throw { message: 'no userId' };
            }
            // const accessToken = __createTokens(user.get());
            return resolve(user.get({ present: true }));
        } catch (error) {
            return reject(error);
        }
    });
}

function __createTokens(payload) {
    const accessToken = jwt.sign(payload, jwtConfig.accessTokenSecret, __getSignOptions(jwtConfig.accessTokenLife));
    return accessToken;
}

function __getSignOptions(tokenLife) {
    return { algorithm: 'HS256', expiresIn: tokenLife };
}

module.exports = {
    createUser,
    getUser,
    updateUser,
    deleteUser,
    login
};
