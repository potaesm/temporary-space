function User(userId = null, username = null, password = null, userType = null, employeeId = null, name = null) {
	this.userId = userId;
	this.username = username;
	this.password = password;
	this.userType = userType;
	this.employeeId = employeeId;
	this.name = name;
}
User.prototype.map = function (object) {
	if (!object) return;
	object.userId !== undefined ? this.userId = object.userId : void (0);
	object.username !== undefined ? this.username = object.username : void (0);
	object.password !== undefined ? this.password = object.password : void (0);
	object.userType !== undefined ? this.userType = object.userType : void (0);
	object.employeeId !== undefined ? this.employeeId = object.employeeId : void (0);
	object.name !== undefined ? this.name = object.name : void (0);
}
User.prototype.get = function (options = { mandatory: false, optional: false, present: false, compact: false }) {
	let o = {
		_userId: this.userId,
		username: this.username,
		password: this.password,
		userType: this.userType,
		_employeeId: this.employeeId,
		_name: this.name
	};
	if (options.mandatory && !options.optional) o = Object.fromEntries(Object.entries(o).filter(_ => !_[0].startsWith('_')));
	if (options.optional && !options.mandatory) o = Object.fromEntries(Object.entries(o).filter(_ => _[0].startsWith('_')));
	if (options.present) o = Object.fromEntries(Object.entries(o).filter(_ => _[1] !== null));
	if (options.compact) o = Object.fromEntries(Object.entries(o).filter(_ => !!_[1]));
	return Object.fromEntries(Object.entries(o).map(_ => { _[0] = _[0].replace('_', ''); return _; }));
}
User.prototype.getUserId = function () { return this.userId }
User.prototype.getUsername = function () { return this.username }
User.prototype.getPassword = function () { return this.password }
User.prototype.getUserType = function () { return this.userType }
User.prototype.getEmployeeId = function () { return this.employeeId }
User.prototype.getName = function () { return this.name }
User.prototype.setUserId = function (userId) { userId !== undefined ? this.userId = userId : void (0) }
User.prototype.setUsername = function (username) { username !== undefined ? this.username = username : void (0) }
User.prototype.setPassword = function (password) { password !== undefined ? this.password = password : void (0) }
User.prototype.setUserType = function (userType) { userType !== undefined ? this.userType = userType : void (0) }
User.prototype.setEmployeeId = function (employeeId) { employeeId !== undefined ? this.employeeId = employeeId : void (0) }
User.prototype.setName = function (name) { name !== undefined ? this.name = name : void (0) }
User.prototype.isEmpty = function () { return !Object.values(this).filter(_ => _ !== null).length }
User.prototype.isFull = function () { return !Object.values(this).includes(null) }
User.prototype.isValid = function (options = { mandatory: false, optional: false }) {
	const o = {
		_userId: this.userId,
		username: this.username,
		password: this.password,
		userType: this.userType,
		_employeeId: this.employeeId,
		_name: this.name
	};
	let entries = Object.entries(o);
	if (options.mandatory && !options.optional) entries = entries.filter(_ => !_[0].startsWith('_'));
	if (options.optional && !options.mandatory) entries = entries.filter(_ => _[0].startsWith('_'));
	return !Object.values(Object.fromEntries(entries)).includes(null);
}
User.prototype.listMissingFields = function (options = { mandatory: false, optional: false }) {
	const o = {
		_userId: this.userId,
		username: this.username,
		password: this.password,
		userType: this.userType,
		_employeeId: this.employeeId,
		_name: this.name
	};
	let entries = Object.entries(o);
	if (options.mandatory && !options.optional) entries = entries.filter(_ => !_[0].startsWith('_'));
	if (options.optional && !options.mandatory) entries = entries.filter(_ => _[0].startsWith('_'));
	return entries.filter(_ => _[1] === null).map(_ => _[0].replace('_', ''));
}
module.exports = User;
