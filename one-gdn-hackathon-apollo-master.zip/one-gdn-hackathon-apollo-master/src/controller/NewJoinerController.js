const { NewJoinerUser } = require('../model');
const { NewJoinerService } = require('../service');

module.exports = (router = require('express').Router()) => {
    router.get('/list/:newJoinerId?', async (request, response) => {
        try {
            const newJoinerId = request.params.newJoinerId;
            const results = await NewJoinerService.getNewJoiner(newJoinerId);
            return response.send(results);
        } catch (error) {
            return response.status(500).send(error);
        }
    });

    router.patch('/update/:newJoinerId', async (request, response) => {
		try {
            const newJoinerId = request.params.newJoinerId;
            const newJoinerUser = new NewJoinerUser();
            newJoinerUser.map({ ...request.body, newJoinerId });
            if (!!newJoinerUser.getNewJoinerId() && !!newJoinerUser.getUserId()) {
                const result = await NewJoinerService.updateNewJoiner(newJoinerUser.get({ present: true }));
                return response.send(result);
            }
            throw { message: 'newJoinerId and userId are mandatory' };
		} catch (error) {
			return response.status(500).send(error);
		}
	});

    return router;
};
