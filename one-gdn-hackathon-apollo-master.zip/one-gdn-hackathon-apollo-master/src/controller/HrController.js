const { mysqlConfig, table } = require('../config/dbConfig.json');
const { MysqlService } = require('../service');

module.exports = (router = require('express').Router()) => {
    router.get('/init', async (request, response) => {
		try {
			const results = await MysqlService.QUERY(
				'CREATE TABLE `' +
                mysqlConfig.database +
					'`.`hr` ( `hrId` INT NOT NULL AUTO_INCREMENT, `userId` INT NOT NULL, PRIMARY KEY (`hrId`), INDEX `userId_idx` (`userId` ASC) VISIBLE, CONSTRAINT `hrUserId` FOREIGN KEY (`userId`) REFERENCES `simple`.`user` (`userId`) ON DELETE CASCADE ON UPDATE NO ACTION);'
			);
			return response.send(results);
		} catch (error) {
			return response.status(500).send(error);
		}
	});

	router.get('/list/:hrId?', async (request, response) => {
        try {
			const findObject = {};
			if (!!request.params.hrId) {
				findObject[`${table.hr.indexName}`] = request.params.hrId;
			}
            const results = await MysqlService.findWhere(table.hr.name, table.hr.indexName, findObject);
            return response.send(results);
        } catch (error) {
            return response.status(500).send(error);
        }
    });

	return router;
};
