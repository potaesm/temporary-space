const { MysqlService, MysqlBlobService } = require('../service');
const path = require('path');
const os = require('os');
const multer = require('multer');
const upload = multer({ dest: path.join(os.tmpdir(), '/').split(path.sep).join('/') });

module.exports = (router = require('express').Router()) => {
	router.get('/createSimpleTable/:schema', async (request, response) => {
		try {
			const results = await MysqlService.QUERY(
				'CREATE TABLE `' +
					request.params.schema +
					'`.`simple` (`id` INT NOT NULL AUTO_INCREMENT,`title` VARCHAR(45) NULL,`detail` VARCHAR(45) NULL,`name` VARCHAR(45) NULL,PRIMARY KEY (`id`))'
			);
			return response.send(results);
		} catch (error) {
			return response.send(error);
		}
	});

	router.get('/page/:table', async (request, response) => {
		try {
			const indexName = request.query.index_name;
			const results = await MysqlService.findPage(request.params.table, !!indexName ? indexName : 'id', request.query.sort_object, request.query.page_size, request.query.page_number);
			return response.send(results);
		} catch (error) {
			return response.send(error);
		}
	});

	router.get('/filter/:table', async (request, response) => {
		try {
			const indexName = request.query.index_name;
			const results = await MysqlService.findWhere(request.params.table, !!indexName ? indexName : 'id', request.query.find_object);
			return response.send(results);
		} catch (error) {
			return response.send(error);
		}
	});

	router.get('/read/:table/:id?', async (request, response) => {
		try {
			const results = await MysqlService.findById(request.params.table, request.params.id);
			return response.send(results);
		} catch (error) {
			return response.send(error);
		}
	});

	router.post('/create/:table', async (request, response) => {
		try {
			const indexName = request.query.index_name;
			const results = await MysqlService.insert(request.params.table, !!indexName ? indexName : 'id', request.body);
			return response.send(results);
		} catch (error) {
			return response.send(error);
		}
	});

	router.patch('/update/:table/:id?', async (request, response) => {
		try {
			let results = {};
			if (!!request.params.id) {
				results = await MysqlService.updateById(request.params.table, request.params.id, request.body);
			} else {
				results = await MysqlService.updateWhere(request.params.table, request.query.find_object, request.body);
			}
			return response.send(results);
		} catch (error) {
			return response.send(error);
		}
	});

	router.delete('/delete/:table/:id?', async (request, response) => {
		try {
			let results = {};
			if (!!request.params.id) {
				results = await MysqlService.deleteById(request.params.table, request.params.id);
			} else {
				results = await MysqlService.deleteWhere(request.params.table, request.query.find_object);
			}
			return response.send(results);
		} catch (error) {
			return response.send(error);
		}
	});

	router.get('/createFileTable/:schema', async (request, response) => {
		try {
			const results = await MysqlService.QUERY(
				'CREATE TABLE `' +
					request.params.schema +
					'`.`files` ( `id` INT NOT NULL AUTO_INCREMENT , `name` VARCHAR(40) NOT NULL , `mimetype` VARCHAR(40) NOT NULL , `data` LONGBLOB NOT NULL , PRIMARY KEY (`id`))'
			);
			return response.send(results);
		} catch (error) {
			return response.send(error);
		}
	});

	router.post('/upload-file/:table', upload.any(), async (request, response) => {
        try {
            const files = request.files;
            if (!!files && files.length > 0) {
                const resultPromises = [];
				const uploadBody = [];
                for (let fileNum = 0; fileNum < files.length; fileNum++) {
					const file = files[fileNum];
					const fileName = file.originalname;
					const mimetype = MysqlBlobService.getMimeType(fileName);
					uploadBody.push({ name: fileName, mimetype });
                    const blob = MysqlBlobService.getBlob(file.path);
                    resultPromises.push(blob);
                    await new Promise(resolve => setImmediate(_ => resolve()));
                }
                const blobArray = await Promise.all(resultPromises);
				uploadBody.map((file, index) => {
					file.data = blobArray[index];
					return file;
				});
				const indexName = request.query.index_name;
				const insertResults = await MysqlService.insert(request.params.table, !!indexName ? indexName : 'id', uploadBody);
                return response.send(insertResults);
            } else {
                return response.send('No files');
            }
        } catch (error) {
            return response.send(error);
        }
    });

	router.get('/download-file/:table/:file_name', async (request, response) => {
        try {
			const indexName = request.query.index_name;
            const fileResult = await MysqlService.findWhere(request.params.table, !!indexName ? indexName : 'id', { name: request.params.file_name });
			const { name, mimetype, data } = fileResult[0];
            const encodedFileName = encodeURIComponent(name).replace(/['()]/g, escape).replace(/\*/g, '%2A').replace(/%(?:7C|60|5E)/g, unescape);
            response.set({
                /** Force browser to download file */
                // 'Content-Disposition': `attachment; filename*=UTF-8''${encodedFileName}`,
                /** Preview file in browser */
                'Content-Disposition': `inline; filename*=UTF-8''${encodedFileName}`,
                'Content-Type': mimetype,
                'Last-Modified': (new Date()).toUTCString(),
                'Cache-Control': 'no-cache'
            });
            return response.send(data);
        } catch (error) {
            return response.send(error);
        }
    });

	return router;
};
