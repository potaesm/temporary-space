const MysqlService = require('./MysqlService');
const { table } = require('../config/dbConfig.json');
const { Journey } = require('../model');

function createJourney(journey = null) {
    return new Promise(async (resolve, reject) => {
        try {
            const journeyArray = [];
            if (Array.isArray(journey)) {
                journeyArray.push(...journey);
            } else {
                journeyArray.push(journey);
            }
            const checkExistPromises = [];
            for (const item of journeyArray) {
                const newJourney = new Journey();
                newJourney.map(item);
                if (!newJourney.getJourneyName()) {
                    throw { message: 'journeyName is mandatory' };
                }
                checkExistPromises.push(MysqlService.findWhere(table.journey.name, table.journey.indexName, { journeyName: newJourney.getJourneyName() }));
            }
            const checkExistArray = await Promise.all(checkExistPromises);
            for (const item of checkExistArray) {
                if (!!item.length) {
                    throw { message: 'journeyName is existed' };
                }
            }
            const result = await MysqlService.insert(table.journey.name, table.journey.indexName, journeyArray);
            return resolve(result);
        } catch (error) {
            return reject(error);
        }
    });
}

function getJourney(journeyId = null) {
    return new Promise(async (resolve, reject) => {
        try {
            const findObject = {};
            if (journeyId !== undefined && journeyId !== null) {
                findObject[`${table.journey.indexName}`] = journeyId;
            }
            const results = await MysqlService.findWhere(table.journey.name, table.journey.indexName, findObject);
            return resolve(results);
        } catch (error) {
            return reject(error);
        }
    });
}

function updateJourney(journeyId = null, journeyDoc = null) {
    return new Promise(async (resolve, reject) => {
        try {
            const toUpdateJourney = new Journey();
            toUpdateJourney.map(journeyDoc);
            toUpdateJourney.setJourneyId(null);
            const result = await MysqlService.updateWhere(table.journey.name, { journeyId }, toUpdateJourney.get({ present: true }));
            return resolve(result);
        } catch (error) {
            return reject(error);
        }
    });
}

function deleteJourney(journeyId = null) {
    return new Promise(async (resolve, reject) => {
        try {
            const findObject = {};
            if (journeyId !== undefined && journeyId !== null) {
                findObject[`${table.journey.indexName}`] = journeyId;
            }
            const result = await MysqlService.deleteWhere(table.journey.name, findObject);
            return resolve(result);
        } catch (error) {
            return reject(error);
        }
    });
}

module.exports = {
    createJourney,
    getJourney,
    updateJourney,
    deleteJourney
};
