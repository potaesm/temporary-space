# Apollo

-   My personal host (only for testing) {{host}} = https://hackathon-apollo-be.herokuapp.com
-   My personal DB config

```json
{
	"host": "remotemysql.com",
	"user": "eHxiLUM2Xe",
	"password": "HeTTpHcm4D",
	"database": "eHxiLUM2Xe"
}
```

-   My personal DB Manager https://potae-phpmyadmin.herokuapp.com/

# File

## Upload file

POST {{host}}/file/upload [with formdata/files]

## List files

GET {{host}}/file/list/:fileId?

## Update file

PATCH {{host}}/file/update/:fileId

## Delete files

DELETE {{host}}/file/delete/:fileId?

# User

## Create user

POST {{host}}/user/create [with json body]

-   userType

```json
{
	"default": 0,
	"newJoiner": 1,
	"hr": 2,
	"admin": 3
}
```

-   example body

```json
{
	"username": "hr",
	"password": "1234",
	"userType": 2
}
```

## List user

GET {{host}}/user/list/:username?

## Login

POST {{host}}/user/login [with json body]

-   Example body

```json
{
	"username": "hr",
	"password": "1234"
}
```

## Update user

PATCH {{host}}/user/update/:userId [with json body]

-   Example body

```json
{
	"username": "hr",
	"password": "1234",
	"employeeId": "251171",
	"name": "Suthinan Musitmani"
}
```

## Delete user

DELETE {{host}}/user/delete/:userId?

-   Caution: if no userId specified, it will delete entire table

# New joiner

## List new joiner

GET {{host}}/new-joiner/list/:newJoinerId?

## Update new joiner

PATCH {{host}}/new-joiner/update/:newJoinerId [with json body]

-   Example body

```json
{
    "userId": 1,
    "manager": "Igor",
    "team": "IDLB",
    "startDate": "2020-07-01",
    "probationEndDate": "2020-10-01",
    "employeeId": "251171",
    "name": "Suthinan Musitmani"
}
```

# Journey

## Create journey

POST {{host}}/journey/create [with json body]

-   Example body

```json
{
	"journeyName": "journey1"
}
```

## List journey

GET {{host}}/journey/list/:journeyId?

## Update journey

PATCH {{host}}/journey/update/:journeyId [with json body]

-   Example body

```json
{
	"journeyName": "newJourney"
}
```

## Delete journey

DELETE {{host}}/journey/delete/:journeyId?

# New joiner journey

## Assign journey to new joiner

POST {{host}}/new-joiner-journey/assign-journey/:newJoinerId/:journeyId

## Unassign journey from new joiner

DELETE {{host}}/new-joiner-journey/unassign-journey/:newJoinerId/:journeyId

# Task

## Create task

POST {{host}}/task/create/:journeyId/:fileId [with json body]

-   Example body

```json
{
	"taskType": 0,
	"taskName": "Welcome to Allianz Technology from Head of GDN Ashish"
}
```

## List tasks

GET {{host}}/task/list/:taskId?

## Update tasks

PATCH {{host}}/task/update/:taskId [with json body]

-   Example body

```json
{
	"journeyId": 7,
	"fileId": 1,
	"taskType": 0,
	"taskName": "Hello"
}
```

## Delete tasks

DELETE {{host}}/task/delete/:taskId?
