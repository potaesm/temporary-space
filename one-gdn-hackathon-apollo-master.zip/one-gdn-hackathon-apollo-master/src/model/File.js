function File(fileId = null, fileName = null, mimetype = null, data = null) {
	this.fileId = fileId;
	this.fileName = fileName;
	this.mimetype = mimetype;
	this.data = data;
}
File.prototype.map = function (object) {
	if (!object) return;
	object.fileId !== undefined ? this.fileId = object.fileId : void (0);
	object.fileName !== undefined ? this.fileName = object.fileName : void (0);
	object.mimetype !== undefined ? this.mimetype = object.mimetype : void (0);
	object.data !== undefined ? this.data = object.data : void (0);
}
File.prototype.get = function (options = { mandatory: false, optional: false, present: false, compact: false }) {
	let o = {
		_fileId: this.fileId,
		fileName: this.fileName,
		mimetype: this.mimetype,
		data: this.data
	};
	if (options.mandatory && !options.optional) o = Object.fromEntries(Object.entries(o).filter(_ => !_[0].startsWith('_')));
	if (options.optional && !options.mandatory) o = Object.fromEntries(Object.entries(o).filter(_ => _[0].startsWith('_')));
	if (options.present) o = Object.fromEntries(Object.entries(o).filter(_ => _[1] !== null));
	if (options.compact) o = Object.fromEntries(Object.entries(o).filter(_ => !!_[1]));
	return Object.fromEntries(Object.entries(o).map(_ => { _[0] = _[0].replace('_', ''); return _; }));
}
File.prototype.getFileId = function () { return this.fileId }
File.prototype.getFileName = function () { return this.fileName }
File.prototype.getMimetype = function () { return this.mimetype }
File.prototype.getData = function () { return this.data }
File.prototype.setFileId = function (fileId) { fileId !== undefined ? this.fileId = fileId : void (0) }
File.prototype.setFileName = function (fileName) { fileName !== undefined ? this.fileName = fileName : void (0) }
File.prototype.setMimetype = function (mimetype) { mimetype !== undefined ? this.mimetype = mimetype : void (0) }
File.prototype.setData = function (data) { data !== undefined ? this.data = data : void (0) }
File.prototype.isEmpty = function () { return !Object.values(this).filter(_ => _ !== null).length }
File.prototype.isFull = function () { return !Object.values(this).includes(null) }
File.prototype.isValid = function (options = { mandatory: false, optional: false }) {
	const o = {
		_fileId: this.fileId,
		fileName: this.fileName,
		mimetype: this.mimetype,
		data: this.data
	};
	let entries = Object.entries(o);
	if (options.mandatory && !options.optional) entries = entries.filter(_ => !_[0].startsWith('_'));
	if (options.optional && !options.mandatory) entries = entries.filter(_ => _[0].startsWith('_'));
	return !Object.values(Object.fromEntries(entries)).includes(null);
}
File.prototype.listMissingFields = function (options = { mandatory: false, optional: false }) {
	const o = {
		_fileId: this.fileId,
		fileName: this.fileName,
		mimetype: this.mimetype,
		data: this.data
	};
	let entries = Object.entries(o);
	if (options.mandatory && !options.optional) entries = entries.filter(_ => !_[0].startsWith('_'));
	if (options.optional && !options.mandatory) entries = entries.filter(_ => _[0].startsWith('_'));
	return entries.filter(_ => _[1] === null).map(_ => _[0].replace('_', ''));
}
module.exports = File;
