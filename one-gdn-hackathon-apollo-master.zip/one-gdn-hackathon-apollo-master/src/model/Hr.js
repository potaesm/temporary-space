function Hr(hrId = null, userId = null) {
	this.hrId = hrId;
	this.userId = userId;
}
Hr.prototype.map = function (object) {
	if (!object) return;
	object.hrId !== undefined ? this.hrId = object.hrId : void (0);
	object.userId !== undefined ? this.userId = object.userId : void (0);
}
Hr.prototype.get = function (options = { mandatory: false, optional: false, present: false, compact: false }) {
	let o = {
		_hrId: this.hrId,
		_userId: this.userId
	};
	if (options.mandatory && !options.optional) o = Object.fromEntries(Object.entries(o).filter(_ => !_[0].startsWith('_')));
	if (options.optional && !options.mandatory) o = Object.fromEntries(Object.entries(o).filter(_ => _[0].startsWith('_')));
	if (options.present) o = Object.fromEntries(Object.entries(o).filter(_ => _[1] !== null));
	if (options.compact) o = Object.fromEntries(Object.entries(o).filter(_ => !!_[1]));
	return Object.fromEntries(Object.entries(o).map(_ => { _[0] = _[0].replace('_', ''); return _; }));
}
Hr.prototype.getHrId = function () { return this.hrId }
Hr.prototype.getUserId = function () { return this.userId }
Hr.prototype.setHrId = function (hrId) { hrId !== undefined ? this.hrId = hrId : void (0) }
Hr.prototype.setUserId = function (userId) { userId !== undefined ? this.userId = userId : void (0) }
Hr.prototype.isEmpty = function () { return !Object.values(this).filter(_ => _ !== null).length }
Hr.prototype.isFull = function () { return !Object.values(this).includes(null) }
Hr.prototype.isValid = function (options = { mandatory: false, optional: false }) {
	const o = {
		_hrId: this.hrId,
		_userId: this.userId
	};
	let entries = Object.entries(o);
	if (options.mandatory && !options.optional) entries = entries.filter(_ => !_[0].startsWith('_'));
	if (options.optional && !options.mandatory) entries = entries.filter(_ => _[0].startsWith('_'));
	return !Object.values(Object.fromEntries(entries)).includes(null);
}
Hr.prototype.listMissingFields = function (options = { mandatory: false, optional: false }) {
	const o = {
		_hrId: this.hrId,
		_userId: this.userId
	};
	let entries = Object.entries(o);
	if (options.mandatory && !options.optional) entries = entries.filter(_ => !_[0].startsWith('_'));
	if (options.optional && !options.mandatory) entries = entries.filter(_ => _[0].startsWith('_'));
	return entries.filter(_ => _[1] === null).map(_ => _[0].replace('_', ''));
}
module.exports = Hr;
