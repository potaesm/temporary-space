const MysqlService = require('./MysqlService');
const { table } = require('../config/dbConfig.json');
const { Task } = require('../model');

function getTask(taskId = null) {
    return new Promise(async (resolve, reject) => {
        try {
            const results = await MysqlService.findWhere(table.task.name, table.task.indexName, { taskId });
            return resolve(results);
        } catch (error) {
            return reject(error);
        }
    });
}

function createTask(journeyId = null, fileId = null, body = {}) {
    return new Promise(async (resolve, reject) => {
        try {
            /** Check if task exist */
            const results = await MysqlService.findWhere(table.task.name, table.task.indexName, { journeyId, fileId });
            if (!!results.length) {
                throw { message: 'task existed' };
            }
            /** Insert new task */
            const newTask = new Task();
            newTask.map({ ...body, journeyId, fileId });
            const result = await MysqlService.insert(table.task.name, table.task.indexName, newTask.get({ present: true }));
            return resolve(result);
        } catch (error) {
            return reject(error);
        }
    });
}

function updateTask(taskId = null, body = {}) {
    return new Promise(async (resolve, reject) => {
        try {
            const newTask = new Task();
            newTask.map(body);
            newTask.setTaskId(null);
            /** Check if task exist */
            const existResults = await MysqlService.findWhere(table.task.name, table.task.indexName, { journeyId: newTask.getJourneyId(), fileId: newTask.getFileId() });
            if (!!existResults.length) {
                const existTask = new Task();
                existTask.map(existResults[0]);
                if (Number(existTask.getTaskId()) !== Number(taskId)) {
                    throw { message: 'task existed' };
                }
            }
            const results = await MysqlService.updateWhere(table.task.name, { taskId }, newTask.get({ present: true }));
            return resolve(results);
        } catch (error) {
            return reject(error);
        }
    });
}

function deleteTask(taskId = null) {
    return new Promise(async (resolve, reject) => {
        try {
            const result = await MysqlService.deleteWhere(table.task.name, { taskId });
            return resolve(result);
        } catch (error) {
            return reject(error);
        }
    });
}

module.exports = {
    getTask,
    createTask,
    updateTask,
    deleteTask
};
