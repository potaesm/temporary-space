const express = require('express');
const cors = require('cors');
const helmet = require('helmet');

const PORT = process.env.PORT || 3000;

const {
	SimpleMysqlController,
	UserController,
	HrController,
	NewJoinerController,
	FileController,
	JourneyController,
	NewJoinerJourneyController,
	TaskController,
	DbController
} = require('./src/controller');

function startExpress() {
	const app = express();

	app.use(express.json());
	app.use(cors({ origin: true }));
	app.use(helmet());

	// app.use('/simple', SimpleMysqlController());
	app.use('/user', UserController());
	// app.use('/hr', HrController());
	app.use('/new-joiner', NewJoinerController());
	app.use('/file', FileController());
	app.use('/journey', JourneyController());
	app.use('/new-joiner-journey', NewJoinerJourneyController());
	app.use('/task', TaskController());
	app.use('/db', DbController());

	app.listen(PORT);
}

startExpress();
