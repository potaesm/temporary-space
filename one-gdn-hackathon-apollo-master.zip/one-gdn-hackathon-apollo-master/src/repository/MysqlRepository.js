const mysql = require('mysql');
const util = require('util');

function QUERY(sql, db = __getDb()) {
	return new Promise(async (resolve, reject) => {
		try {
			const result = await db.query(sql);
			return resolve(result);
		} catch (error) {
			return reject(error);
		} finally {
			await db.close();
		}
	});
}

function FIND(option = { table: '', indexName: '', findObject: {}, sortObject: {}, pageSize: 0, pageNumber: 0 }) {
	const { table, indexName } = option;
	const sortObject = typeof option.sortObject === 'string' && !!option.sortObject ? JSON.parse(option.sortObject) : (!!option.sortObject ? option.sortObject : {});
	const findObject = typeof option.findObject === 'string' && !!option.findObject ? JSON.parse(option.findObject) : (!!option.findObject ? option.findObject : {});
	const pageSize = !!option.pageSize ? Number(option.pageSize) : 0;
	const pageNumber = !!option.pageNumber ? Number(option.pageNumber) : 0;
	return new Promise(async (resolve, reject) => {
		try {
			if (!table) {
				throw { message: 'FIND - table is mandatory' };
			}
			const findObjectEntries = findObject !== undefined && findObject !== null ? Object.entries(findObject) : [];
			const sortObjectEntries = sortObject !== undefined && sortObject !== null ? Object.entries(sortObject) : [];
			/** Where clause */
			let whereClause = '';
			if (!!findObjectEntries.length) {
				whereClause = await __getWhereClause(table, findObjectEntries);
			}
			/** Sorting */
			let orderByClause = ` ORDER BY ${indexName} ASC`;
			if (!!sortObjectEntries.length) {
				const sortEntry = sortObjectEntries[0];
				const sortKey = sortEntry[0];
				const sortValue = `${sortEntry[1]}`.toUpperCase();
				if (sortValue === 'ASC' || sortValue === 'DESC') {
					orderByClause = ` ORDER BY ${sortKey} ${sortValue}`;
				}
			}
			/** Pagination */
			const limitClause = __getLimitClause(pageSize, pageNumber);
			/** Query */
			const results = await QUERY(`SELECT * FROM ${table}${whereClause}${orderByClause}${limitClause}`);
			return resolve(results);
		} catch (error) {
			return reject(error);
		}
	});
}

function INSERT(option = { table: '', indexName: '', doc: {} }) {
	const { table, indexName, doc } = option;
	return new Promise(async (resolve, reject) => {
		try {
			if (!table) {
				throw { message: 'INSERT - table is mandatory' };
			}
			let documents = [];
			if (Array.isArray(doc)) {
				documents = doc;
			} else {
				const isDocEmpty = await __isEmpty(doc);
				if (!isDocEmpty) documents.push(doc);
			}
			const columnNameArray = [];
			const rowDocArray = [];
			for (let docNum = 0; docNum < documents.length; docNum++) {
				const valueArray = [];
				if (!!indexName && !!documents[docNum][`${indexName}`]) {
					delete documents[docNum][`${indexName}`];
				}
				const docEntries = Object.entries(documents[docNum]);
				for (let entryNum = 0; entryNum < docEntries.length; entryNum++) {
					const key = docEntries[entryNum][0];
					const value = docEntries[entryNum][1];
					if (docNum == 0) {
						columnNameArray.push(key);
					}
					valueArray.push(__getParsedValue(value));
					await new Promise(resolve => setImmediate(resolve()));
				}
				rowDocArray.push(`(${valueArray})`);
				await new Promise(resolve => setImmediate(resolve()));
			}
			const results = await QUERY(`INSERT INTO ${table} (${columnNameArray}) VALUES ${rowDocArray}`);
			return resolve(results);
		} catch (error) {
			return reject(error);
		}
	});
}

function UPDATE(option = { table: '', indexName: '', findObject: {}, doc: {} }) {
	const { table, indexName, doc } = option;
	const findObject = typeof option.findObject === 'string' && !!option.findObject ? JSON.parse(option.findObject) : (!!option.findObject ? option.findObject : {});
	return new Promise(async (resolve, reject) => {
		try {
			/** Set clause */
			let setClause = '';
			const valueArray = [];
			if (!!indexName && !!doc[`${indexName}`]) {
				delete doc[`${indexName}`];
			}
			const docEntries = Object.entries(doc);
			for (let entryNum = 0; entryNum < docEntries.length; entryNum++) {
				const key = docEntries[entryNum][0];
				let value = docEntries[entryNum][1];
				/** Type correction */
				const parsedValue = __getParsedValue(value);
				valueArray.push(`${key} = ` + parsedValue);
				await new Promise(resolve => setImmediate(resolve()));
			}
			setClause = ` SET ${valueArray}`;
			/** Where clause */
			const findObjectEntries = findObject !== undefined && findObject !== null ? Object.entries(findObject) : [];
			let whereClause = '';
			if (!!findObjectEntries.length) {
				whereClause = await __getWhereClause(table, findObjectEntries);
			}
			const results = await QUERY(`UPDATE ${table}${setClause}${whereClause}`);
			return resolve(results);
		} catch (error) {
			return reject(error);
		}
	});
}

function DELETE(option = { table: '', findObject: {} }) {
	const { table } = option;
	const findObject = typeof option.findObject === 'string' && !!option.findObject ? JSON.parse(option.findObject) : (!!option.findObject ? option.findObject : {});
	return new Promise(async (resolve, reject) => {
		try {
			/** Where clause */
			const findObjectEntries = findObject !== undefined && findObject !== null ? Object.entries(findObject) : [];
			let whereClause = '';
			if (!!findObjectEntries.length) {
				whereClause = await __getWhereClause(table, findObjectEntries);
			}
			const results = await QUERY(`DELETE FROM ${table}${whereClause}`);
			return resolve(results);
		} catch (error) {
			return reject(error);
		}
	});
}

function __getDb(config = require('../config/dbConfig.json').mysqlConfig) {
	const connection = mysql.createConnection(config);
	return {
		query(sql, args) {
			return util.promisify(connection.query).call(connection, sql, args);
		},
		close() {
			return util.promisify(connection.end).call(connection);
		},
	};
}

async function __isEmpty(obj = {}) {
	const keys = Object.keys(obj);
	for (let keyNum = 0; keyNum < keys.length; keyNum++) {
		if (obj.hasOwnProperty(keys[keyNum])) return false;
		await new Promise(resolve => setImmediate(resolve()));
	}
	return true;
}

function __getWhereClause(table = '', findObjectEntries = []) {
	return new Promise(async (resolve, reject) => {
		try {
			let whereClause = '';
			const findKeyArray = [];
			const findValueArray = [];
			if (!findObjectEntries.map(_ => typeof _[1]).includes('object')) {
				for (let entryNum = 0; entryNum < findObjectEntries.length; entryNum++) {
					const findEntry = findObjectEntries[entryNum];
					const findKey = findEntry[0];
					let findValue = findEntry[1];
					findKeyArray.push(findKey);
					/** Type correction */
					findValueArray.push(__getParsedValue(findValue));
					await new Promise(resolve => setImmediate(resolve()));
				}
				for (let findKeyNum = 0; findKeyNum < findKeyArray.length; findKeyNum++) {
					if (findKeyNum === 0) {
						whereClause = ` WHERE ${table}.${findKeyArray[findKeyNum]} = ${findValueArray[findKeyNum]}`;
					} else {
						whereClause = whereClause + ` AND ${table}.${findKeyArray[findKeyNum]} = ${findValueArray[findKeyNum]}`;
					}
					await new Promise(resolve => setImmediate(resolve()));
				}
			}
			return resolve(whereClause);
		} catch (error) {
			return reject(error);
		}
	});
}

/** Apply pagination */
function __getLimitClause(pageSize = 0, pageNumber = 0) {
	let limitClause = '';
	if (pageSize > 0 && pageNumber > 0) {
		const offset = (pageNumber - 1) * pageSize;
		limitClause = ` LIMIT ${pageSize} OFFSET ${offset};`
	}
	return limitClause;
}

function __getParsedValue(value) {
	switch (typeof value) {
		case 'number': {
			return `${value}`;
		}
		case 'string': {
			return `'${value}'`;
		}
		case 'boolean': {
			return `'${value}'`;
		}
		case 'object': {
			return `CHAR(${value})`;
		}
		default:
			return '';
	}
}

module.exports = {
	QUERY,
	FIND,
	INSERT,
	UPDATE,
	DELETE,
};
