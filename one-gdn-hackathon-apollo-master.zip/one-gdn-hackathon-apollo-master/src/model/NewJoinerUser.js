function NewJoinerUser(newJoinerId = null, userId = null, manager = null, team = null, startDate = null, probationEndDate = null, employeeId = null, name = null, username = null, userType = null) {
	this.newJoinerId = newJoinerId;
	this.userId = userId;
	this.manager = manager;
	this.team = team;
	this.startDate = startDate;
	this.probationEndDate = probationEndDate;
	this.employeeId = employeeId;
	this.name = name;
	this.username = username;
	this.userType = userType;
}
NewJoinerUser.prototype.map = function (object) {
	if (!object) return;
	object.newJoinerId !== undefined ? this.newJoinerId = object.newJoinerId : void (0);
	object.userId !== undefined ? this.userId = object.userId : void (0);
	object.manager !== undefined ? this.manager = object.manager : void (0);
	object.team !== undefined ? this.team = object.team : void (0);
	object.startDate !== undefined ? this.startDate = object.startDate : void (0);
	object.probationEndDate !== undefined ? this.probationEndDate = object.probationEndDate : void (0);
	object.employeeId !== undefined ? this.employeeId = object.employeeId : void (0);
	object.name !== undefined ? this.name = object.name : void (0);
	object.username !== undefined ? this.username = object.username : void (0);
	object.userType !== undefined ? this.userType = object.userType : void (0);
}
NewJoinerUser.prototype.get = function (options = { mandatory: false, optional: false, present: false, compact: false }) {
	let o = {
		newJoinerId: this.newJoinerId,
		userId: this.userId,
		manager: this.manager,
		team: this.team,
		startDate: this.startDate,
		probationEndDate: this.probationEndDate,
		employeeId: this.employeeId,
		name: this.name,
		username: this.username,
		userType: this.userType
	};
	if (options.mandatory && !options.optional) o = Object.fromEntries(Object.entries(o).filter(_ => !_[0].startsWith('_')));
	if (options.optional && !options.mandatory) o = Object.fromEntries(Object.entries(o).filter(_ => _[0].startsWith('_')));
	if (options.present) o = Object.fromEntries(Object.entries(o).filter(_ => _[1] !== null));
	if (options.compact) o = Object.fromEntries(Object.entries(o).filter(_ => !!_[1]));
	return Object.fromEntries(Object.entries(o).map(_ => { _[0] = _[0].replace('_', ''); return _; }));
}
NewJoinerUser.prototype.getNewJoinerId = function () { return this.newJoinerId }
NewJoinerUser.prototype.getUserId = function () { return this.userId }
NewJoinerUser.prototype.getManager = function () { return this.manager }
NewJoinerUser.prototype.getTeam = function () { return this.team }
NewJoinerUser.prototype.getStartDate = function () { return this.startDate }
NewJoinerUser.prototype.getProbationEndDate = function () { return this.probationEndDate }
NewJoinerUser.prototype.getEmployeeId = function () { return this.employeeId }
NewJoinerUser.prototype.getName = function () { return this.name }
NewJoinerUser.prototype.getUsername = function () { return this.username }
NewJoinerUser.prototype.getUserType = function () { return this.userType }
NewJoinerUser.prototype.setNewJoinerId = function (newJoinerId) { newJoinerId !== undefined ? this.newJoinerId = newJoinerId : void (0) }
NewJoinerUser.prototype.setUserId = function (userId) { userId !== undefined ? this.userId = userId : void (0) }
NewJoinerUser.prototype.setManager = function (manager) { manager !== undefined ? this.manager = manager : void (0) }
NewJoinerUser.prototype.setTeam = function (team) { team !== undefined ? this.team = team : void (0) }
NewJoinerUser.prototype.setStartDate = function (startDate) { startDate !== undefined ? this.startDate = startDate : void (0) }
NewJoinerUser.prototype.setProbationEndDate = function (probationEndDate) { probationEndDate !== undefined ? this.probationEndDate = probationEndDate : void (0) }
NewJoinerUser.prototype.setEmployeeId = function (employeeId) { employeeId !== undefined ? this.employeeId = employeeId : void (0) }
NewJoinerUser.prototype.setName = function (name) { name !== undefined ? this.name = name : void (0) }
NewJoinerUser.prototype.setUsername = function (username) { username !== undefined ? this.username = username : void (0) }
NewJoinerUser.prototype.setUserType = function (userType) { userType !== undefined ? this.userType = userType : void (0) }
NewJoinerUser.prototype.isEmpty = function () { return !Object.values(this).filter(_ => _ !== null).length }
NewJoinerUser.prototype.isFull = function () { return !Object.values(this).includes(null) }
NewJoinerUser.prototype.isValid = function (options = { mandatory: false, optional: false }) {
	const o = {
		newJoinerId: this.newJoinerId,
		userId: this.userId,
		manager: this.manager,
		team: this.team,
		startDate: this.startDate,
		probationEndDate: this.probationEndDate,
		employeeId: this.employeeId,
		name: this.name,
		username: this.username,
		userType: this.userType
	};
	let entries = Object.entries(o);
	if (options.mandatory && !options.optional) entries = entries.filter(_ => !_[0].startsWith('_'));
	if (options.optional && !options.mandatory) entries = entries.filter(_ => _[0].startsWith('_'));
	return !Object.values(Object.fromEntries(entries)).includes(null);
}
NewJoinerUser.prototype.listMissingFields = function (options = { mandatory: false, optional: false }) {
	const o = {
		newJoinerId: this.newJoinerId,
		userId: this.userId,
		manager: this.manager,
		team: this.team,
		startDate: this.startDate,
		probationEndDate: this.probationEndDate,
		employeeId: this.employeeId,
		name: this.name,
		username: this.username,
		userType: this.userType
	};
	let entries = Object.entries(o);
	if (options.mandatory && !options.optional) entries = entries.filter(_ => !_[0].startsWith('_'));
	if (options.optional && !options.mandatory) entries = entries.filter(_ => _[0].startsWith('_'));
	return entries.filter(_ => _[1] === null).map(_ => _[0].replace('_', ''));
}
module.exports = NewJoinerUser;
