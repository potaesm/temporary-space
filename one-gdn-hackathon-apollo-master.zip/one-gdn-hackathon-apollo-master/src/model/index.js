const NewJoiner = require('./NewJoiner');
const File = require('./File');
const Hr = require('./Hr');
const User = require('./User');
const Journey = require('./Journey');
const NewJoinerJourney = require('./NewJoinerJourney');
const Task = require('./Task');
const NewJoinerUser = require('./NewJoinerUser');

module.exports = {
    NewJoiner,
    File,
    Hr,
    User,
    Journey,
    NewJoinerJourney,
    Task,
    NewJoinerUser
};
