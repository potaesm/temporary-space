const SimpleMysqlController = require('./SimpleMysqlController');
const NewJoinerController = require('./NewJoinerController');
const FileController = require('./FileController');
const HrController = require('./HrController');
const UserController = require('./UserController');
const JourneyController = require('./JourneyController');
const NewJoinerJourneyController = require('./NewJoinerJourneyController');
const TaskController = require('./TaskController');
const DbController = require('./DbController');

module.exports = {
	SimpleMysqlController,
	NewJoinerController,
	FileController,
	HrController,
	UserController,
	JourneyController,
	NewJoinerJourneyController,
	TaskController,
	DbController
};
