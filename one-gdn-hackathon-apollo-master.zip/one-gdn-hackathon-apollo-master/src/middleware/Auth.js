const crypto = require('crypto');
const jwt = require('jsonwebtoken');
const jwtConfig = require('../config/jwtConfig.json');
const { table } = require('../config/dbConfig.json');
const { User } = require('../model');
const { MysqlService } = require('../service');

async function validateUserPassword(request, response, next) {
    const user = new User();
    user.map(request.body);
    if (!!user.getUsername() && !!user.getPassword()) {
        const existUserResults = await MysqlService.findWhere(table.user.name, table.user.indexName, { username: user.getUsername() });
        const existUser = new User();
        existUser.map(existUserResults[0]);
        if (!!existUserResults && !existUserResults.length) {
            return response.status(404).send({ message: 'user not found' });
        }
        const splitPasswordList = existUser.getPassword().split('$');
        const salt = splitPasswordList[0];
        const hash = crypto.createHmac('sha512', salt).update(user.getPassword()).digest('base64');
        if (hash === splitPasswordList[1]) {
            user.setUserId(existUser.getUserId());
            user.setEmployeeId(existUser.getEmployeeId());
            user.setName(existUser.getName());
            user.setUserType(existUser.getUserType());
            user.setPassword(null);
            request.body = user.get({ present: true });
            return next();
        }
        return response.status(401).send({ message: 'incorrect password' });
    }
    return response.status(400).send('username and password are mandatory');
}

function validateRequiredPermission(type) {
    return function (request, response, next) {
        const userType = Number(request.jwt.type);
        if (userType >= type) {
            return next();
        }
        return response.status(412).send({ message: 'not allow' });
    }
}

function validateJwtInCookies(request, response, next) {
    const cookies = !!request.signedCookies ? request.signedCookies : request.cookies;
    if (!cookies) {
        return response.status(401).send({ message: 'cookies not found' });
    }
    const accessToken = cookies.jwt;
    if (!accessToken) {
        return response.status(401).send({ message: 'jwt not found in cookies' });
    }
    try {
        request.jwt = jwt.verify(accessToken, jwtConfig.accessTokenSecret);
        return next();
    } catch (error) {
        return response.status(403).send(error);
    }
}

module.exports = {
    validateUserPassword,
    validateRequiredPermission,
    validateJwtInCookies
};
