function Journey(journeyId = null, journeyName = null) {
	this.journeyId = journeyId;
	this.journeyName = journeyName;
}
Journey.prototype.map = function (object) {
	if (!object) return;
	object.journeyId !== undefined ? this.journeyId = object.journeyId : void (0);
	object.journeyName !== undefined ? this.journeyName = object.journeyName : void (0);
}
Journey.prototype.get = function (options = { mandatory: false, optional: false, present: false, compact: false }) {
	let o = {
		_journeyId: this.journeyId,
		journeyName: this.journeyName
	};
	if (options.mandatory && !options.optional) o = Object.fromEntries(Object.entries(o).filter(_ => !_[0].startsWith('_')));
	if (options.optional && !options.mandatory) o = Object.fromEntries(Object.entries(o).filter(_ => _[0].startsWith('_')));
	if (options.present) o = Object.fromEntries(Object.entries(o).filter(_ => _[1] !== null));
	if (options.compact) o = Object.fromEntries(Object.entries(o).filter(_ => !!_[1]));
	return Object.fromEntries(Object.entries(o).map(_ => { _[0] = _[0].replace('_', ''); return _; }));
}
Journey.prototype.getJourneyId = function () { return this.journeyId }
Journey.prototype.getJourneyName = function () { return this.journeyName }
Journey.prototype.setJourneyId = function (journeyId) { journeyId !== undefined ? this.journeyId = journeyId : void (0) }
Journey.prototype.setJourneyName = function (journeyName) { journeyName !== undefined ? this.journeyName = journeyName : void (0) }
Journey.prototype.isEmpty = function () { return !Object.values(this).filter(_ => _ !== null).length }
Journey.prototype.isFull = function () { return !Object.values(this).includes(null) }
Journey.prototype.isValid = function (options = { mandatory: false, optional: false }) {
	const o = {
		_journeyId: this.journeyId,
		journeyName: this.journeyName
	};
	let entries = Object.entries(o);
	if (options.mandatory && !options.optional) entries = entries.filter(_ => !_[0].startsWith('_'));
	if (options.optional && !options.mandatory) entries = entries.filter(_ => _[0].startsWith('_'));
	return !Object.values(Object.fromEntries(entries)).includes(null);
}
Journey.prototype.listMissingFields = function (options = { mandatory: false, optional: false }) {
	const o = {
		_journeyId: this.journeyId,
		journeyName: this.journeyName
	};
	let entries = Object.entries(o);
	if (options.mandatory && !options.optional) entries = entries.filter(_ => !_[0].startsWith('_'));
	if (options.optional && !options.mandatory) entries = entries.filter(_ => _[0].startsWith('_'));
	return entries.filter(_ => _[1] === null).map(_ => _[0].replace('_', ''));
}
module.exports = Journey;
