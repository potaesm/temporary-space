function Task(taskId = null, journeyId = null, fileId = null, taskType = null, taskName = null, taskContent = null, response = null) {
	this.taskId = taskId;
	this.journeyId = journeyId;
	this.fileId = fileId;
	this.taskType = taskType;
	this.taskName = taskName;
	this.taskContent = taskContent;
	this.response = response;
}
Task.prototype.map = function (object) {
	if (!object) return;
	object.taskId !== undefined ? this.taskId = object.taskId : void (0);
	object.journeyId !== undefined ? this.journeyId = object.journeyId : void (0);
	object.fileId !== undefined ? this.fileId = object.fileId : void (0);
	object.taskType !== undefined ? this.taskType = object.taskType : void (0);
	object.taskName !== undefined ? this.taskName = object.taskName : void (0);
	object.taskContent !== undefined ? this.taskContent = object.taskContent : void (0);
	object.response !== undefined ? this.response = object.response : void (0);
}
Task.prototype.get = function (options = { mandatory: false, optional: false, present: false, compact: false }) {
	let o = {
		_taskId: this.taskId,
		journeyId: this.journeyId,
		fileId: this.fileId,
		taskType: this.taskType,
		taskName: this.taskName,
		_taskContent: this.taskContent,
		_response: this.response
	};
	if (options.mandatory && !options.optional) o = Object.fromEntries(Object.entries(o).filter(_ => !_[0].startsWith('_')));
	if (options.optional && !options.mandatory) o = Object.fromEntries(Object.entries(o).filter(_ => _[0].startsWith('_')));
	if (options.present) o = Object.fromEntries(Object.entries(o).filter(_ => _[1] !== null));
	if (options.compact) o = Object.fromEntries(Object.entries(o).filter(_ => !!_[1]));
	return Object.fromEntries(Object.entries(o).map(_ => { _[0] = _[0].replace('_', ''); return _; }));
}
Task.prototype.getTaskId = function () { return this.taskId }
Task.prototype.getJourneyId = function () { return this.journeyId }
Task.prototype.getFileId = function () { return this.fileId }
Task.prototype.getTaskType = function () { return this.taskType }
Task.prototype.getTaskName = function () { return this.taskName }
Task.prototype.getTaskContent = function () { return this.taskContent }
Task.prototype.getResponse = function () { return this.response }
Task.prototype.setTaskId = function (taskId) { taskId !== undefined ? this.taskId = taskId : void (0) }
Task.prototype.setJourneyId = function (journeyId) { journeyId !== undefined ? this.journeyId = journeyId : void (0) }
Task.prototype.setFileId = function (fileId) { fileId !== undefined ? this.fileId = fileId : void (0) }
Task.prototype.setTaskType = function (taskType) { taskType !== undefined ? this.taskType = taskType : void (0) }
Task.prototype.setTaskName = function (taskName) { taskName !== undefined ? this.taskName = taskName : void (0) }
Task.prototype.setTaskContent = function (taskContent) { taskContent !== undefined ? this.taskContent = taskContent : void (0) }
Task.prototype.setResponse = function (response) { response !== undefined ? this.response = response : void (0) }
Task.prototype.isEmpty = function () { return !Object.values(this).filter(_ => _ !== null).length }
Task.prototype.isFull = function () { return !Object.values(this).includes(null) }
Task.prototype.isValid = function (options = { mandatory: false, optional: false }) {
	const o = {
		_taskId: this.taskId,
		journeyId: this.journeyId,
		fileId: this.fileId,
		taskType: this.taskType,
		taskName: this.taskName,
		_taskContent: this.taskContent,
		_response: this.response
	};
	let entries = Object.entries(o);
	if (options.mandatory && !options.optional) entries = entries.filter(_ => !_[0].startsWith('_'));
	if (options.optional && !options.mandatory) entries = entries.filter(_ => _[0].startsWith('_'));
	return !Object.values(Object.fromEntries(entries)).includes(null);
}
Task.prototype.listMissingFields = function (options = { mandatory: false, optional: false }) {
	const o = {
		_taskId: this.taskId,
		journeyId: this.journeyId,
		fileId: this.fileId,
		taskType: this.taskType,
		taskName: this.taskName,
		_taskContent: this.taskContent,
		_response: this.response
	};
	let entries = Object.entries(o);
	if (options.mandatory && !options.optional) entries = entries.filter(_ => !_[0].startsWith('_'));
	if (options.optional && !options.mandatory) entries = entries.filter(_ => _[0].startsWith('_'));
	return entries.filter(_ => _[1] === null).map(_ => _[0].replace('_', ''));
}
module.exports = Task;
