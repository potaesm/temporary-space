const MysqlService = require('./MysqlService');
const { table } = require('../config/dbConfig.json');

function createHr(userId = 0) {
    return new Promise(async (resolve, reject) => {
        try {
            const result = await MysqlService.insert(table.hr.name, table.hr.indexName, { userId });
            return resolve(result);
        } catch (error) {
            return reject(error);
        }
    });
}

module.exports = {
    createHr
};
