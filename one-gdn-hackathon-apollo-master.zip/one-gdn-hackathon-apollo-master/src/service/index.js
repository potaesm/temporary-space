const MysqlService = require('./MysqlService');
const MysqlBlobService = require('./MysqlBlobService');
const UserService = require('./UserService');
const HrService = require('./HrService');
const NewJoinerService = require('./NewJoinerService');
const JourneyService = require('./JourneyService');
const NewJoinerJourneyService = require('./NewJoinerJourneyService');
const TaskService = require('./TaskService');

module.exports = {
	MysqlService,
	MysqlBlobService,
	UserService,
	HrService,
	NewJoinerService,
	JourneyService,
	NewJoinerJourneyService,
	TaskService
};
