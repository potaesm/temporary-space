# NEW USER

-   HR

```json
{
	"username": "hr",
	"password": "hr",
	"userType": 2,
	"name": "Eliza Hart",
	"employeeId": "21222"
}
```

-   NEW JOINER

```json
{
	"username": "employee1",
	"password": "employee1",
	"userType": 1,
	"name": "John Doe",
	"employeeId": "100200"
}
```

```json
{
	"username": "employee2",
	"password": "employee2",
	"userType": 1,
	"name": "William Stock",
	"employeeId": "100210"
}
```

```json
{
	"username": "employee3",
	"password": "employee3",
	"userType": 1,
	"name": "Susan Adroth",
	"employeeId": "100220"
}
```

# UPDATE NEW JOINER
```bash
/:newJoinerId
```
```json
{
	"userId": 0,
	"manager": "Christ Evan",
	"team": "Team A",
	"startDate": "2021-06-01",
	"probationEndDate": "2021-06-01",
	"name": "John Doe"
}
```
```json
{
	"userId": 0,
	"manager": "Tony Stark",
	"team": "Team B",
	"startDate": "2021-06-05",
	"probationEndDate": "2021-06-05",
	"name": "William Stock"
}
```
```json
{
	"userId": 0,
	"manager": "Stephen Strange",
	"team": "Team C",
	"startDate": "2021-06-01",
	"probationEndDate": "2021-06-01",
	"name": "Susan Adroth"
}
```

# CREATE JOURNEY
```json
[
    {
        "journeyName": "Pre-onboard"
    },
    {
        "journeyName": "Day1"
    },
    {
        "journeyName": "Ongoing"
    }
]
```

# UPLOAD FILE

# ASSIGN JOURNEY TO NEW JOINER
```bash
/:newJoinerId/:journeyId
```

# CREATE TASK
```bash
/:journeyId/:fileId
```
- Pre-onboard
```json
{
	"taskType": 1,
	"taskName": "Survey - Recruitment process",
	"taskContent": 1
}
```
```json
{
	"taskType": 1,
	"taskName": "How excited are you to join us",
	"taskContent": 1
}
```
```json
{
	"taskType": 2,
	"taskName": "Request IT Assets",
	"taskContent": 2
}
```
```json
{
	"taskType": 2,
	"taskName": "Request user account",
	"taskContent": 2
}
```
```json
{
	"taskType": 2,
	"taskName": "Request office access card",
	"taskContent": 2
}
```
```json
{
	"taskType": 2,
	"taskName": "Adding to mailing list",
	"taskContent": 2
}
```
- Day1
```json
{
	"taskType": 0,
	"taskName": "Allianz History",
	"taskContent": 1
}
```
```json
{
	"taskType": 0,
	"taskName": "GDN Location",
	"taskContent": 1
}
```
```json
{
	"taskType": 0,
	"taskName": "Global executive team",
	"taskContent": 1
}
```
```json
{
	"taskType": 0,
	"taskName": "Welcome to Allianz Technology from Head of GDN Ashish",
	"taskContent": 1
}
```
```json
{
	"taskType": 0,
	"taskName": "Company structure",
	"taskContent": 1
}
```
```json
{
	"taskType": 1,
	"taskName": "Who is CEO of Allianz Technology Thailand",
	"taskContent": 1
}
```
```json
{
	"taskType": 0,
	"taskName": "Message from Head of Pillar",
	"taskContent": 1
}
```
```json
{
	"taskType": 0,
	"taskName": "What do you need to do on first day",
	"taskContent": 1
}
```
```json
{
	"taskType": 0,
	"taskName": "Allianz Thailand Holiday Calendar",
	"taskContent": 1
}
```
```json
{
	"taskType": 0,
	"taskName": "Tools that we use",
	"taskContent": 1
}
```
```json
{
	"taskType": 2,
	"taskName": "Access to your laptop",
	"taskContent": 1
}
```
```json
{
	"taskType": 2,
	"taskName": "Access to Outlook",
	"taskContent": 1
}
```
- Ongoing
```json
{
	"taskType": 1,
	"taskName": "How would you rate your first week at Allianz",
	"taskContent": 1
}
```
```json
{
	"taskType": 2,
	"taskName": "Access to E-pay slip",
	"taskContent": 1
}
```
```json
{
	"taskType": 1,
	"taskName": "How would you rate your overall onboarding process",
	"taskContent": 1
}
```
```json
{
	"taskType": 2,
	"taskName": "Access to enroll Provident fund",
	"taskContent": 1
}
```
```json
{
	"taskType": 0,
	"taskName": "Mid propation",
	"taskContent": 1
}
```