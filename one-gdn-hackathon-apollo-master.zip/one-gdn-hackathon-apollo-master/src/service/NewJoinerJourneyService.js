const MysqlService = require('./MysqlService');
const { table, mysqlConfig } = require('../config/dbConfig.json');

function getNewJoinerJourney(newJoinerId = null) {
    return new Promise(async (resolve, reject) => {
        try {
            const database = mysqlConfig.database;
            const selectedColumn = [
                `${database}.${table.newJoiner.name}.${table.newJoiner.indexName}`,
                `${database}.${table.journey.name}.${table.journey.indexName}`,
                `${database}.${table.journey.name}.journeyName`,
                `${database}.${table.task.name}.${table.task.indexName}`,
                `${database}.${table.task.name}.fileId`,
                `${database}.${table.task.name}.taskType`,
                `${database}.${table.task.name}.taskName`,
                `${database}.${table.task.name}.response`
            ];
            const newJoinerUser = `SELECT ${selectedColumn} FROM ${database}.${table.newJoinerJourney.name} JOIN ${database}.${table.newJoiner.name} ON ${database}.${table.newJoinerJourney.name}.newJoinerId = ${database}.${table.newJoiner.name}.newJoinerId JOIN ${database}.${table.journey.name} ON ${database}.${table.newJoinerJourney.name}.journeyId = ${database}.${table.journey.name}.journeyId JOIN ${database}.${table.task.name} ON ${database}.${table.newJoinerJourney.name}.journeyId = ${database}.${table.task.name}.journeyId `;
            const whereClause = (newJoinerId !== undefined && newJoinerId !== null) ? ` AND ${mysqlConfig.database}.${table.newJoiner.name}.${table.newJoiner.indexName} = ${newJoinerId};` : '';
            const results = await MysqlService.QUERY(newJoinerUser + whereClause);
            let newJoinerJourney = {};
            let journeyNameDict = {};
            /** Restructure 1 */
            for (let i = 0; i < results.length; i++) {
                const item = results[i];
                const { newJoinerId, journeyId, journeyName, taskId, fileId, taskType, taskName, response } = item;
                journeyNameDict[`${journeyId}`] = journeyName;
                if (!newJoinerJourney[`${newJoinerId}`]) {
                    newJoinerJourney[`${newJoinerId}`] = {};
                }
                if (!newJoinerJourney[`${newJoinerId}`][`${journeyId}`]) {
                    newJoinerJourney[`${newJoinerId}`][`${journeyId}`] = {};
                }
                if (!newJoinerJourney[`${newJoinerId}`][`${journeyId}`][`${taskId}`]) {
                    newJoinerJourney[`${newJoinerId}`][`${journeyId}`][`${taskId}`] = {};
                }
                newJoinerJourney[`${newJoinerId}`][`${journeyId}`][`${taskId}`] = { fileId, taskType, taskName, response };
            }
            /** Restructure 2 */
            const newJoinerJourneyArray = [];
            const newJoinerJourneyEntries = Object.entries(newJoinerJourney);
            for (let i = 0; i < newJoinerJourneyEntries.length; i++) {
                const newJoiner = newJoinerJourneyEntries[i];
                const newJoinerId = newJoiner[0];
                const journeyArray = [];
                const journeyEntries = Object.entries(newJoiner[1]);
                for (let j = 0; j < journeyEntries.length; j++) {
                    const journey = journeyEntries[j];
                    const journeyId = journey[0];
                    const journeyName = journeyNameDict[`${journeyId}`];
                    const taskArray = [];
                    const taskEntries = Object.entries(journey[1]);
                    for (let k = 0; k < taskEntries.length; k++) {
                        const task = taskEntries[k];
                        const taskId = task[0];
                        taskArray.push({ taskId, ...task[1] });
                    }
                    journeyArray.push({ journeyId, journeyName, task: taskArray });
                }
                newJoinerJourneyArray.push({ newJoinerId, journey: journeyArray });
            }
            return resolve(newJoinerJourneyArray);
        } catch (error) {
            return reject(error);
        }
    });
}

function assignJourneyToNewJoiner(newJoinerId = null, journeyId = null) {
    return new Promise(async (resolve, reject) => {
        try {
            /** Check if journey exist */
            const results = await MysqlService.findWhere(table.newJoinerJourney.name, table.newJoinerJourney.indexName, { newJoinerId, journeyId });
            if (!!results.length) {
                throw { message: 'journey existed in this newJoiner' };
            }
            /** Insert new journey */
            const result = await MysqlService.insert(table.newJoinerJourney.name, table.newJoinerJourney.indexName, { newJoinerId, journeyId });
            return resolve(result);
        } catch (error) {
            return reject(error);
        }
    });
}

function unAssignJourneyFromNewJoiner(newJoinerId = null, journeyId = null) {
    return new Promise(async (resolve, reject) => {
        try {
            const result = await MysqlService.deleteWhere(table.newJoinerJourney.name, { newJoinerId, journeyId });
            return resolve(result);
        } catch (error) {
            return reject(error);
        }
    });
}

module.exports = {
    getNewJoinerJourney,
    assignJourneyToNewJoiner,
    unAssignJourneyFromNewJoiner
};
