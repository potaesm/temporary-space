function NewJoiner(newJoinerId = null, userId = null, manager = null, team = null, startDate = null, probationEndDate = null) {
	this.newJoinerId = newJoinerId;
	this.userId = userId;
	this.manager = manager;
	this.team = team;
	this.startDate = startDate;
	this.probationEndDate = probationEndDate;
}
NewJoiner.prototype.map = function (object) {
	if (!object) return;
	object.newJoinerId !== undefined ? this.newJoinerId = object.newJoinerId : void (0);
	object.userId !== undefined ? this.userId = object.userId : void (0);
	object.manager !== undefined ? this.manager = object.manager : void (0);
	object.team !== undefined ? this.team = object.team : void (0);
	object.startDate !== undefined ? this.startDate = object.startDate : void (0);
	object.probationEndDate !== undefined ? this.probationEndDate = object.probationEndDate : void (0);
}
NewJoiner.prototype.get = function (options = { mandatory: false, optional: false, present: false, compact: false }) {
	let o = {
		_newJoinerId: this.newJoinerId,
		userId: this.userId,
		manager: this.manager,
		team: this.team,
		startDate: this.startDate,
		probationEndDate: this.probationEndDate
	};
	if (options.mandatory && !options.optional) o = Object.fromEntries(Object.entries(o).filter(_ => !_[0].startsWith('_')));
	if (options.optional && !options.mandatory) o = Object.fromEntries(Object.entries(o).filter(_ => _[0].startsWith('_')));
	if (options.present) o = Object.fromEntries(Object.entries(o).filter(_ => _[1] !== null));
	if (options.compact) o = Object.fromEntries(Object.entries(o).filter(_ => !!_[1]));
	return Object.fromEntries(Object.entries(o).map(_ => { _[0] = _[0].replace('_', ''); return _; }));
}
NewJoiner.prototype.getNewJoinerId = function () { return this.newJoinerId }
NewJoiner.prototype.getUserId = function () { return this.userId }
NewJoiner.prototype.getManager = function () { return this.manager }
NewJoiner.prototype.getTeam = function () { return this.team }
NewJoiner.prototype.getStartDate = function () { return this.startDate }
NewJoiner.prototype.getProbationEndDate = function () { return this.probationEndDate }
NewJoiner.prototype.setNewJoinerId = function (newJoinerId) { newJoinerId !== undefined ? this.newJoinerId = newJoinerId : void (0) }
NewJoiner.prototype.setUserId = function (userId) { userId !== undefined ? this.userId = userId : void (0) }
NewJoiner.prototype.setManager = function (manager) { manager !== undefined ? this.manager = manager : void (0) }
NewJoiner.prototype.setTeam = function (team) { team !== undefined ? this.team = team : void (0) }
NewJoiner.prototype.setStartDate = function (startDate) { startDate !== undefined ? this.startDate = startDate : void (0) }
NewJoiner.prototype.setProbationEndDate = function (probationEndDate) { probationEndDate !== undefined ? this.probationEndDate = probationEndDate : void (0) }
NewJoiner.prototype.isEmpty = function () { return !Object.values(this).filter(_ => _ !== null).length }
NewJoiner.prototype.isFull = function () { return !Object.values(this).includes(null) }
NewJoiner.prototype.isValid = function (options = { mandatory: false, optional: false }) {
	const o = {
		_newJoinerId: this.newJoinerId,
		userId: this.userId,
		manager: this.manager,
		team: this.team,
		startDate: this.startDate,
		probationEndDate: this.probationEndDate
	};
	let entries = Object.entries(o);
	if (options.mandatory && !options.optional) entries = entries.filter(_ => !_[0].startsWith('_'));
	if (options.optional && !options.mandatory) entries = entries.filter(_ => _[0].startsWith('_'));
	return !Object.values(Object.fromEntries(entries)).includes(null);
}
NewJoiner.prototype.listMissingFields = function (options = { mandatory: false, optional: false }) {
	const o = {
		_newJoinerId: this.newJoinerId,
		userId: this.userId,
		manager: this.manager,
		team: this.team,
		startDate: this.startDate,
		probationEndDate: this.probationEndDate
	};
	let entries = Object.entries(o);
	if (options.mandatory && !options.optional) entries = entries.filter(_ => !_[0].startsWith('_'));
	if (options.optional && !options.mandatory) entries = entries.filter(_ => _[0].startsWith('_'));
	return entries.filter(_ => _[1] === null).map(_ => _[0].replace('_', ''));
}
module.exports = NewJoiner;
