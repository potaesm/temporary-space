const { NewJoinerJourneyService } = require('../service');

module.exports = (router = require('express').Router()) => {
    router.get('/list/:newJoinerId?', async (request, response) => {
        try {
            const newJoinerId = request.params.newJoinerId;
            const results = await NewJoinerJourneyService.getNewJoinerJourney(newJoinerId);
            return response.send(results);
        } catch (error) {
            return response.status(500).send(error);
        }
    });

    router.get('/list-v2/:newJoinerId?', async (request, response) => {
        try {
            const newJoinerId = request.params.newJoinerId;
            const results = await NewJoinerJourneyService.getNewJoinerJourneyV2(newJoinerId);
            return response.send(results);
        } catch (error) {
            return response.status(500).send(error);
        }
    });

    router.post('/assign-journey/:newJoinerId/:journeyId', async (request, response) => {
        try {
            const newJoinerId = request.params.newJoinerId;
            const journeyId = request.params.journeyId;
            if (newJoinerId !== undefined && newJoinerId !== null && journeyId !== undefined && journeyId !== null) {
                const result = await NewJoinerJourneyService.assignJourneyToNewJoiner(newJoinerId, journeyId);
                return response.send(result);
            }
            throw { message: 'newJoinerId and journeyId are mandatory' };
        } catch (error) {
            return response.status(500).send(error);
        }
    });

    router.delete('/unassign-journey/:newJoinerId/:journeyId', async (request, response) => {
        try {
            const newJoinerId = request.params.newJoinerId;
            const journeyId = request.params.journeyId;
            if (newJoinerId !== undefined && newJoinerId !== null && journeyId !== undefined && journeyId !== null) {
                const result = await NewJoinerJourneyService.unAssignJourneyFromNewJoiner(newJoinerId, journeyId);
                return response.send(result);
            }
            throw { message: 'newJoinerId and journeyId are mandatory' };
        } catch (error) {
            return response.status(500).send(error);
        }
    });

    return router;
};
