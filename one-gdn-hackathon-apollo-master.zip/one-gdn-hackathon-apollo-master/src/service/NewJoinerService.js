const MysqlService = require('./MysqlService');
const { table, mysqlConfig } = require('../config/dbConfig.json');
const { NewJoinerUser, NewJoiner, User } = require('../model');

function createNewJoiner(userId = null) {
    return new Promise(async (resolve, reject) => {
        try {
            const result = await MysqlService.insert(table.newJoiner.name, table.newJoiner.indexName, { userId });
            return resolve(result);
        } catch (error) {
            return reject(error);
        }
    });
}

function getNewJoiner(newJoinerId = null) {
    return new Promise(async (resolve, reject) => {
        try {
            const selectedColumn = ['newJoinerId', `${table.user.name}.${table.user.indexName}`, 'manager', 'team', 'startDate', 'probationEndDate', 'employeeId', 'name', 'username', 'userType'];
            const newJoinerUser = `SELECT ${selectedColumn} FROM ${mysqlConfig.database}.${table.newJoiner.name} INNER JOIN ${mysqlConfig.database}.${table.user.name} WHERE ${mysqlConfig.database}.${table.newJoiner.name}.${table.user.indexName} = ${mysqlConfig.database}.${table.user.name}.${table.user.indexName}`;
            const whereClause = (newJoinerId !== undefined && newJoinerId !== null) ? ` AND ${mysqlConfig.database}.${table.newJoiner.name}.${table.newJoiner.indexName} = ${newJoinerId};` : '';
            const results = await MysqlService.QUERY(newJoinerUser + whereClause);
            return resolve(results);
        } catch (error) {
            return reject(error);
        }
    });
}

function updateNewJoiner(newJoinerUserDoc = null) {
    return new Promise(async (resolve, reject) => {
        try {
            const newJoinerUser = new NewJoinerUser();
            newJoinerUser.map(newJoinerUserDoc);
            /** Prevent from update username and userType */
            newJoinerUser.setUsername(null);
            newJoinerUser.setUserType(null);
            const toUpdateNewJoiner = new NewJoiner();
            toUpdateNewJoiner.map(newJoinerUser.get({ present: true }));
            // toUpdateNewJoiner.setStartDate(formatDate(toUpdateNewJoiner.getStartDate()));
            // toUpdateNewJoiner.setProbationEndDate(formatDate(toUpdateNewJoiner.getProbationEndDate()));
            const toUpdateUser = new User();
            toUpdateUser.map(newJoinerUser.get({ present: true }));
            /** User update */
            await MysqlService.updateWhere(table.user.name, { userId: toUpdateUser.getUserId() }, toUpdateUser.get({ present: true }));
            /** New joiner update */
            await MysqlService.updateWhere(table.newJoiner.name, { newJoinerId: toUpdateNewJoiner.getNewJoinerId() }, toUpdateNewJoiner.get({ present: true }));
            return resolve({ message: 'updated' });
        } catch (error) {
            return reject(error);
        }
    });
}

function formatDate(date) {
    const newDate = new Date(date);
    return newDate.toISOString().split('.')[0].split('T').join(' ');
}

module.exports = {
    createNewJoiner,
    getNewJoiner,
    updateNewJoiner
};
