const { MysqlService, MysqlBlobService } = require('../service');
const path = require('path');
const os = require('os');
const multer = require('multer');
const upload = multer({ dest: path.join(os.tmpdir(), '/').split(path.sep).join('/') });

const { table } = require('../config/dbConfig.json');
const { File } = require('../model');

module.exports = (router = require('express').Router()) => {
    router.get('/list/:fileId?', async (request, response) => {
        try {
            const findObject = {};
            if (!!request.params.fileId) {
                findObject[`${table.file.indexName}`] = request.params.fileId;
            }
            const results = await MysqlService.findWhere(table.file.name, table.file.indexName, findObject);
            return response.send(results);
        } catch (error) {
            return response.status(500).send(error);
        }
    });

    router.post('/upload', upload.any(), async (request, response) => {
        try {
            const files = request.files;
            if (!!files && files.length > 0) {
                const resultPromises = [];
                let uploadBody = [];
                for (let fileNum = 0; fileNum < files.length; fileNum++) {
                    const file = files[fileNum];
                    const fileName = file.originalname;
                    const mimetype = MysqlBlobService.getMimeType(fileName);
                    const newFile = new File();
                    newFile.setFileName(fileName);
                    newFile.setMimetype(mimetype);
                    uploadBody.push(newFile.get({ present: true }));
                    const blobPromise = MysqlBlobService.getBlob(file.path);
                    resultPromises.push(blobPromise);
                    await new Promise(resolve => setImmediate(_ => resolve()));
                }
                const blobArray = await Promise.all(resultPromises);
                uploadBody = uploadBody.map((file, index) => {
                    const newFile = new File();
                    newFile.map(file);
                    newFile.setData(blobArray[index]);
                    return newFile.get({ mandatory: true });
                });
                const insertResults = await MysqlService.insert(table.file.name, table.file.indexName, uploadBody);
                return response.send(insertResults);
            } else {
                return response.send('missing files');
            }
        } catch (error) {
            return response.status(500).send(error);
        }
    });

    router.patch('/update/:fileId', upload.any(), async (request, response) => {
        try {
            const files = request.files;
            if (!!files && files.length > 0) {
                const newFile = files[0];
                const fileName = newFile.originalname;
                const mimetype = MysqlBlobService.getMimeType(fileName);
                const blob = await MysqlBlobService.getBlob(newFile.path);
                const toUpdateFile = new File();
                toUpdateFile.setFileName(fileName);
                toUpdateFile.setMimetype(mimetype);
                toUpdateFile.setData(blob);
                const findObject = {};
                findObject[`${table.file.indexName}`] = request.params.fileId;
                const result = await MysqlService.updateWhere(table.file.name, findObject, toUpdateFile.get({ present: true }));
                return response.send(result);
            }
            return response.send('missing file');
        } catch (error) {
            return response.status(500).send(error);
        }
    });

    router.get('/download/:fileId', async (request, response) => {
        try {
            const findObject = {};
            findObject[`${table.file.indexName}`] = request.params.fileId;
            const fileResult = await MysqlService.findWhere(table.file.name, table.file.indexName, findObject);
            const { name, mimetype, data } = fileResult[0];
            const encodedFileName = encodeURIComponent(name).replace(/['()]/g, escape).replace(/\*/g, '%2A').replace(/%(?:7C|60|5E)/g, unescape);
            response.set({
                /** Force browser to download file */
                // 'Content-Disposition': `attachment; filename*=UTF-8''${encodedFileName}`,
                /** Preview file in browser */
                'X-Frame-Options': `allow-from *`,
                'Content-Disposition': `inline; filename*=UTF-8''${encodedFileName}`,
                'Content-Security-Policy': `default-src *  data: blob: filesystem: about: ws: wss: 'unsafe-inline' 'unsafe-eval'; script-src * data: blob: 'unsafe-inline' 'unsafe-eval'; connect-src * data: blob: 'unsafe-inline'; img-src * data: blob: 'unsafe-inline'; frame-src * data: blob: ; style-src * data: blob: 'unsafe-inline'; font-src * data: blob: 'unsafe-inline';`,
                'Content-Type': mimetype,
                'Last-Modified': (new Date()).toUTCString(),
                'Cache-Control': 'no-cache'
            });
            return response.send(data);
        } catch (error) {
            return response.status(500).send(error);
        }
    });

    router.get('/download-with-filename/:fileName', async (request, response) => {
        try {
            const fileName = request.params.fileName;
            if (!fileName) {
                throw { message: 'fileName is mandatory' };
            }
            const fileResult = await MysqlService.findWhere(table.file.name, table.file.indexName, { fileName });
            const { name, mimetype, data } = fileResult[0];
            const encodedFileName = encodeURIComponent(name).replace(/['()]/g, escape).replace(/\*/g, '%2A').replace(/%(?:7C|60|5E)/g, unescape);
            response.set({
                /** Force browser to download file */
                // 'Content-Disposition': `attachment; filename*=UTF-8''${encodedFileName}`,
                /** Preview file in browser */
                'Content-Disposition': `inline; filename*=UTF-8''${encodedFileName}`,
                'Content-Security-Policy': 'img-src https: data:;',
                'Content-Type': mimetype,
                'Last-Modified': (new Date()).toUTCString(),
                'Cache-Control': 'no-cache'
            });
            return response.send(data);
        } catch (error) {
            return response.status(500).send(error);
        }
    });

    router.get('/get-content/:fileId', async (request, response) => {
        try {
            const findObject = {};
            findObject[`${table.file.indexName}`] = request.params.fileId;
            const fileResult = await MysqlService.findWhere(table.file.name, table.file.indexName, findObject);
            const { data } = fileResult[0];
            const content = new TextDecoder().decode(data);
            response.set({
                'Content-Security-Policy': `default-src *  data: blob: filesystem: about: ws: wss: 'unsafe-inline' 'unsafe-eval'; script-src * data: blob: 'unsafe-inline' 'unsafe-eval'; connect-src * data: blob: 'unsafe-inline'; img-src * data: blob: 'unsafe-inline'; frame-src * data: blob: ; style-src * data: blob: 'unsafe-inline'; font-src * data: blob: 'unsafe-inline';`
            });
            return response.send(content);
        } catch (error) {
            return response.status(500).send(error);
        }
    });

    router.delete('/delete/:fileId?', async (request, response) => {
        try {
            const findObject = {};
            if (!!request.params.fileId) {
                findObject[`${table.file.indexName}`] = request.params.fileId;
            }
            const result = await MysqlService.deleteWhere(table.file.name, findObject);
            return response.send(result);
        } catch (error) {
            return response.status(500).send(error);
        }
    });

    return router;
};
